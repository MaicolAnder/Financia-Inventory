<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Usuario.php";
	if (empty($_GET["op"]) || !isset($_GET["op"])) {
		header('location: ../index.php');
		exit();
	}
	/*if ($_GET["op"] != "registrar" || $_GET["op"] != "verificar") {
		header('location: ../index.php');
		exit();
	} */
	else {

	$usuario = new Usuario();
	switch ($_GET["op"]) {
		case 'registrar':
			$nombre=isset($_POST["nombre"])?limpiarCadena($_POST["nombre"]):"";
			$tipo_doc=isset($_POST["tipo_doc"])?limpiarCadena($_POST["tipo_doc"]):"";
			$num_doc=isset($_POST["num_doc"])?limpiarCadena($_POST["num_doc"]):"";
			$login=isset($_POST["login"])?limpiarCadena($_POST["login"]):"";
			$clave=isset($_POST["clave"])?limpiarCadena($_POST['clave']):"";			
			$empresa=isset($_POST["emprs"])?limpiarCadena($_POST["emprs"]):"";
			$imagen=isset($_POST["imagen"])?limpiarCadena($_POST['imagen']):"";
			$erro_imagen = isset($_FILES ["imagen"]["error"]);
			$tmp_imgname = isset($_FILES['imagen']["tmp_name"]);
			$cargo="Administrador";

			$verificar = $usuario->verificar_reg($login, $num_doc);
			echo $verificar? '1' : '3';

			//Subir y validar imagenes
			if ( $erro_imagen > 0){
	        	echo "2";
	        }
	        if ( !file_exists($tmp_imgname) || !is_uploaded_file($tmp_imgname)) 
			{
				$imagen = "";
			} 
			else {
				//Optener extencion y validar extencion de la imagen 
				$ext = explode(".", $_FILES['imagen']['name']);
				if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/png" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/gif") 
				{
						$imagen = round(microtime(true)) . '.' . end($ext);
						move_uploaded_file($tmp_imgname, "../files/usuarios/".$imagen);
				} else{
					echo '0';
				}
			}
			$clavehash = hash("SHA256", $clave);
			if (empty($clave) || empty($login)) {
				echo "";
			} else{
				$rspta = $usuario->insertar_new($nombre, $tipo_doc, $num_doc, $cargo, $login, $clavehash, $empresa, $imagen);
				echo $rspta? '1' : '0';
			}
			
			break;
			
		case 'verificar':
			require_once "../modelos/Empresa.php";
			$empresa = new Empresa();
			if (empty($_POST["logina"])|| empty($_POST["clavea"])) {
				echo null;
			}
			if (!isset($_POST["logina"])|| isset($_POST["clavea"])) {
				echo null;
			}

			$logina=isset($_POST["logina"])?limpiarCadena($_POST['logina']):"";
			$clavea=isset($_POST["clavea"])?limpiarCadena($_POST['clavea']):"";

			$clavehash = hash("SHA256", $clavea);
			$rspta = $usuario->verificar($logina, $clavehash);
			$fetch = $rspta->fetch_object();
			if (isset($fetch)) {
				//Variables de la sesión
				$_SESSION['idusuario'] = $fetch->idusuario;
				$_SESSION['nombre'] = $fetch->nombre;
				$_SESSION['imagen'] = $fetch->imagen;
				$_SESSION['login'] = $fetch->login;
				$_SESSION['usuario_admon'] = $fetch->usuario_admon;

				
				//obtner permisos
				$marcados = $usuario->listarmarcados($fetch->idusuario);
				//Almacernar permisos en un array
				$valores = array();
				while ($per = $marcados->fetch_object()) {
					/* Inserta uno o más elementos al final de un array ... Tiene el mismo efecto que: <?php $array[] = $var; ?> */
					array_push($valores, $per->idpermiso);
				}

				//determinar accesos
				in_array(1, $valores)?$_SESSION['Facturar']=1:$_SESSION['Facturar']=0;
				in_array(2, $valores)?$_SESSION['Articulos']=1:$_SESSION['Articulos']=0;
				in_array(3, $valores)?$_SESSION['Categorias']=1:$_SESSION['Categorias']=0;
				in_array(4, $valores)?$_SESSION['Proveedores']=1:$_SESSION['Proveedores']=0;
				in_array(5, $valores)?$_SESSION['Usuarios']=1:$_SESSION['Usuarios']=0;
				in_array(6, $valores)?$_SESSION['Permisos']=1:$_SESSION['Permisos']=0;
				in_array(7, $valores)?$_SESSION['Compras']=1:$_SESSION['Compras']=0;
				in_array(8, $valores)?$_SESSION['Clientes']=1:$_SESSION['Clientes']=0;

				//usuario en empresa
				$empresa_rta = $empresa->mostrar_e($fetch->usuario_admon);
				$empresa_fetch = $empresa_rta->fetch_object();
				if (isset($empresa_fetch)) {
					$_SESSION['idempresa'] = $empresa_fetch->idempresa;
					$_SESSION['nombre_empresa'] = $empresa_fetch->nombre_empresa;
				}
			}
			echo json_encode($fetch);
			break;
		}
	}
