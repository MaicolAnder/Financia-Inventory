<?php 
require "../config/Conexion.php";
Class Persona{
	//Implementar constructor
	public function __constructor(){

	}

	//Implementar metodo para insertar registro
	public function insertar($tipo_persona, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $email, $idempresa){

		$sql = "INSERT INTO persona (tipo_persona, nombre, tipo_doc, num_doc, direccion, telefono, email, empresa_idempresa) VALUES ('$tipo_persona', '$nombre', '$tipo_doc', '$num_doc', '$direccion', '$telefono', '$email', '$idempresa')";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para editar registro
	public function editar($idpersona, $tipo_persona, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $email){

		$sql = "UPDATE persona SET tipo_persona='$tipo_persona',nombre='$nombre',tipo_doc='$tipo_doc',num_doc='$num_doc',direccion='$direccion',telefono='$telefono',email='$email' WHERE idpersona = '$idpersona' ";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para eliminar o acitvar categoria
	public function eliminar($idpersona){

		$sql = "DELETE FROM persona WHERE idpersona='$idpersona'";
		return ejecutarConsulta($sql);
	}
	
	//Implementar metodo para mostar registros
	public function mostrar($idpersona){

		$sql = "SELECT * FROM persona WHERE idpersona='$idpersona'";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros provedores
	public function listarp($idempresa){

		$sql = "SELECT * FROM persona WHERE tipo_persona='Proveedor' AND empresa_idempresa= '$idempresa' ORDER BY idpersona DESC";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para listar  todos los registros cliente
	public function listarc($idempresa){
		$sql = "SELECT * FROM persona WHERE tipo_persona='Cliente' AND empresa_idempresa= '$idempresa' ORDER BY idpersona DESC";
		return ejecutarConsulta($sql);
	}
}
 ?>