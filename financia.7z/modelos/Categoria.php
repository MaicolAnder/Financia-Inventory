<?php 
if (strlen(session_id())<1) 
    session_start();
require "../config/Conexion.php";
Class Categoria{
	//Implementar constructor
	public function __constructor(){

	}

	//Implementar metodo para insertar registro
	public function insertar($nombre, $descripcion, $usuario_admon){

		$sql = "INSERT INTO categoria (nombre, descripcion, condicion, usuario_admon) VALUES ('$nombre','$descripcion','1','$usuario_admon')";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para editar registro
	public function editar($idcategoria, $nombre, $descripcion){

		$sql = "UPDATE categoria SET nombre='$nombre', descripcion='$descripcion' WHERE idcategoria='$idcategoria'";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para desactivar o acitvar categoria
	public function desactivar($idcategoria){

		$sql = "UPDATE categoria SET condicion='0' WHERE idcategoria='$idcategoria'";
		return ejecutarConsulta($sql);
	}
	public function activar($idcategoria){

		$sql = "UPDATE categoria SET condicion='1' WHERE idcategoria='$idcategoria'";
		return ejecutarConsulta($sql);
	}

	//Implementar metodo para mostar registros
	public function mostrar($idcategoria){

		$sql = "SELECT * FROM categoria WHERE idcategoria='$idcategoria'";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros
	public function listar($usuario_admon){

		$sql = "SELECT * FROM categoria WHERE usuario_admon = '$usuario_admon' ORDER BY idcategoria DESC";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para listar los registros y mostrar en el select
	public function select($usuario_admon){

		$sql = "SELECT * FROM categoria WHERE condicion = 1 AND usuario_admon = '$usuario_admon' ORDER BY idcategoria DESC";
		return ejecutarConsulta($sql);
	}

}

 ?>