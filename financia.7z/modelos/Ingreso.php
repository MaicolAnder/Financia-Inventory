<?php 
require "../config/Conexion.php";
Class Ingreso{
	//Implementar constructor
	public function __constructor(){

	}

	//Implementar metodo para insertar registro
	public function insertar($idproveedor, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_compra, $idempresa, $idarticulo, $cantidad, $precio_compra, $precio_venta){

		$sql = "INSERT INTO ingreso (idprovedor, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total_compra, estado, empresa_idempresa) VALUES ('$idproveedor', '$idusuario', '$tipo_comprobante', '$serie_comprobante', '$num_comprobante', '$fecha_hora', '$impuesto', '$total_compra', 'Aceptado', '$idempresa')";
		//return ejecutarConsulta($sql);
		//consulta que devuelve el id de ingreso y agrega los permisos
		$idingresonew = ejecutarConsulta_retornaID($sql);
		$num_elementos = 0;
		$sw=true;
		while ($num_elementos < count($idarticulo)) {
			$sql_detalle = "INSERT INTO detalle_ingreso(idingreso, idarticulo, cantidad, precio_compra, precio_venta) VALUES('$idingresonew','$idarticulo[$num_elementos]', '$cantidad[$num_elementos]', '$precio_compra[$num_elementos]', '$precio_venta[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		
		}
		return $sw;
	}
	
	//Implementar metodo para anular 
	public function anular($idingreso){

		$sql = "UPDATE ingreso SET estado='Anulado' WHERE idingreso='$idingreso'";
		return ejecutarConsulta($sql);
	}
	
	//Implementar metodo para mostar registros
	public function mostrar($idingreso){

		$sql = "SELECT i.idingreso, date(i.fecha_hora) AS fecha, i.idprovedor,p.nombre AS proveedor, u.idusuario, u.nombre AS usuario, i.tipo_comprobante, i.serie_comprobante, i.num_comprobante, i.total_compra, i.impuesto, i.estado FROM ingreso i INNER JOIN persona p ON i.idprovedor=p.idpersona INNER JOIN usuario u ON i.idusuario=u.idusuario WHERE i.idingreso='$idingreso' ORDER BY i.idingreso DESC";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros
	public function listar($idempresa){

		$sql = "SELECT i.idingreso, DATE(i.fecha_hora) AS fecha, i.idprovedor,p.nombre AS proveedor, u.idusuario, u.nombre AS usuario, i.tipo_comprobante, i.serie_comprobante, i.num_comprobante, i.total_compra, i.impuesto, i.estado FROM ingreso i INNER JOIN persona p ON i.idprovedor=p.idpersona INNER JOIN usuario u ON i.idusuario=u.idusuario WHERE i.empresa_idempresa='$idempresa' ORDER BY i.idingreso DESC";
		return ejecutarConsulta($sql);
	}
	public function total_compra(){
		$sql = "SELECT SUM(total_compra) AS total_compra FROM ingreso";
		return ejecutarConsulta($sql);
	}
	
}

 ?>