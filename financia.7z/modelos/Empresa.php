<?php 
require "../config/Conexion.php";
Class Empresa{
	//Implementar constructor
	public function __constructor(){

	}

	public function editar($idpersona, $tipo_persona, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $email){

		$sql = "UPDATE empresa SET nit='', nombre='', tipo_empresa=''  WHERE 1";
		return ejecutarConsulta($sql);
	}
	/*/Implementar metodo para eliminar o acitvar categoria
	public function eliminar($idpersona){

		$sql = "DELETE FROM persona WHERE idpersona='$idpersona'";
		return ejecutarConsulta($sql);
	} */
	
	//Implementar metodo para mostar registros
	public function mostrar_e($id_usuario){

		$sql = "SELECT idempresa, nombre AS nombre_empresa FROM empresa WHERE usuario_idusuario = '$id_usuario'";
		return ejecutarConsulta($sql);
	}
	
}
 ?>