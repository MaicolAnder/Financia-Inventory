<?php 
require "../config/Conexion.php";
Class Egreso{
	//Implementar constructor
	public function __constructor(){

	}
	//Implementar metodo para insertar registro
	public function insertar($nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clave, $imagen, $usuario_admon, $permisos){

		$sql = "INSERT INTO usuario (nombre, tipo_doc, num_doc, direccion, telefono, cargo, login, clave, imagen, condicion, usuario_admon) VALUES ('$nombre', '$tipo_doc', '$num_doc', '$direccion', '$telefono', '$cargo', '$login', '$clave',' $imagen','1','$usuario_admon')";
		//return ejecutarConsulta($sql);
		//consulta que devuelve el id de usuario y agrega los permisos
		$idusuarionew = ejecutarConsulta_retornaID($sql);
		$new_userconf = "INSERT INTO configuracion(nombre, opcion, usuario_idusuario) VALUES ('Default','Factura','$idusuarionew')";
		ejecutarConsulta($new_userconf) or $sw;
		
		$num_elementos = 0;
		$sw=true;
		while ($num_elementos < count($permisos)) {
			$sql_detalle = "INSERT INTO usuario_permiso(idusuario, idpermiso) VALUES('$idusuarionew','$permisos[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		}
		return $sw;
	}
	//Implementar metodo para editar registro
	public function editar($idusuario, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clave, $imagen, $permisos){
		$sql = "UPDATE usuario SET nombre='$nombre',tipo_doc='$tipo_doc',num_doc='$num_doc',direccion='$direccion',telefono='$telefono',cargo='$cargo',login='$login',clave='$clave',imagen='$imagen' WHERE idusuario='$idusuario'";
		ejecutarConsulta($sql);
		$sql_delete = "DELETE FROM  usuario_permiso WHERE idusuario = '$idusuario'";
		ejecutarConsulta($sql_delete);
		$num_elementos = 0;
		$sw=true;
		while ($num_elementos < count($permisos)) {
			$sql_detalle = "INSERT INTO usuario_permiso(idusuario, idpermiso) VALUES('$idusuario','$permisos[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		}
		return $sw;
	}
	//Implementar metodo para desactivar o acitvar USUARIO
	public function desactivar($idusuario){

		$sql = "UPDATE usuario SET condicion='0' WHERE idusuario='$idusuario'";
		return ejecutarConsulta($sql);
	}
	public function activar($idusuario){
		$sql = "UPDATE usuario SET condicion='1' WHERE idusuario='$idusuario'";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para mostar registros
	public function mostrar($idusuario){
		$sql = "SELECT * FROM usuario WHERE idusuario='$idusuario'";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros de egreso
	public function listar($idempresa){
		$sql = "SELECT * FROM egreso_gastos WHERE empresa_idempresa = '$idempresa'";
		return ejecutarConsulta($sql);
	}
	public function listarmarcados($idusuario){
		$sql = "SELECT * FROM usuario_permiso WHERE idusuario = '$idusuario'";
		return ejecutarConsulta($sql);
	}
	public function verificar($login, $clave){
		$sql = "SELECT idusuario, nombre, tipo_doc, num_doc, telefono, cargo,imagen, login, usuario_admon FROM usuario WHERE login = '$login' AND clave = '$clave' AND condicion = '1'";
		return ejecutarConsulta($sql);
	}
	public function insertar_new($nombre, $tipo_doc, $num_doc, $cargo, $login, $clavehash, $empresa, $imagen){
		$num_permisos = 9;
		$sw = true;
		$sql = "INSERT INTO usuario (nombre, tipo_doc, num_doc, cargo, imagen, login, clave, condicion, usuario_admon) VALUES ('$nombre', '$tipo_doc', '$num_doc', '$cargo', '$imagen', '$login', '$clavehash', '1', '1')";
		$idusuario = ejecutarConsulta_retornaID($sql);
		$query = "UPDATE usuario SET usuario_admon = '$idusuario' WHERE idusuario = '$idusuario'";
		ejecutarConsulta($query) or $sw = false ;

		for ($i=1; $i < $num_permisos ; $i++) { 
			$sql_detalle = "INSERT INTO usuario_permiso (idusuario, idpermiso) VALUES ('$idusuario','$i')";
			ejecutarConsulta($sql_detalle) or $sw = false;
		}
		$new_empresa = "INSERT INTO empresa (nombre, usuario_idusuario) VALUES ('$empresa', '$idusuario')";
		$idempresa=ejecutarConsulta_retornaID($new_empresa) or $sw = false;

		$new_userconf = "INSERT INTO configuracion(nombre, opcion, usuario_idusuario) VALUES ('Default','Factura','$idusuario')";
		ejecutarConsulta($new_userconf) or $sw;

		$new_pago = "INSERT INTO pago(fecha_registro, fecha_pago, version_pagada, valor, detalle,usuario_idusuario,empresa_idempresa) VALUES (NOW(),NOW(),'0','0','Registro Gratuito','$idusuario','$idempresa')";
		ejecutarConsulta($new_pago) or $sw;
		#consultas
		
		return $sw;
	}
	public function verificar_reg($login, $num_doc){
		$sql="SELECT login, num_doc FROM usuario WHERE login = '$login' AND num_doc = '$num_doc'";
		return ejecutarConsulta($sql);
	}
	public function usuario_empresa($idusuario_main){
		$sql = "SELECT * FROM usuario WHERE usuario_admon = '$idusuario_main' ";
		return ejecutarConsulta($sql);
	}
}
?>