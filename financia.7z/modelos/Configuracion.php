<?php 
require "../config/Conexion.php";
Class Configuracion{
	//Implementar constructor
	public function __constructor(){

	}
	public function cargar_Config($idusuario){

		$sql = "SELECT VersionApp, InicioApp FROM usuario WHERE idusuario = '$idusuario'";
		return ejecutarConsulta($sql);
	}
	
}

 ?>