<?php 
require "../config/Conexion.php";
Class Articulo{
	//Implementar constructor
	public function __constructor(){

	}

	//Implementar metodo para insertar articulo
	public function insertar($idcategoria,$codigo,$nombre,$stock,$descripcion,$imagen, $precio_venta, $tipo, $idempresa){

		$sql = "INSERT INTO articulo (idcategoria, codigo, nombre, stock, descripcion, imagen, condicion, precio_venta, tipo, empresa_idempresa) VALUES ('$idcategoria','$codigo','$nombre','$stock','$descripcion','$imagen','1', '$precio_venta', '$tipo', '$idempresa')";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para editar registro
	public function editar($idarticulo,$idcategoria, $codigo, $nombre, $descripcion, $imagen, $precio_venta, $tipo){

		$sql = "UPDATE articulo SET idcategoria='$idcategoria', codigo='$codigo', nombre='$nombre', descripcion='$descripcion', imagen='$imagen', precio_venta='$precio_venta', tipo='$tipo' WHERE idarticulo='$idarticulo'";
		return ejecutarConsulta($sql);
	}
	//Implementar metodo para desactivar o acitvar articulo
	public function desactivar($idarticulo){

		$sql = "UPDATE articulo SET condicion='0' WHERE idarticulo='$idarticulo'";
		return ejecutarConsulta($sql);
	}
	public function activar($idarticulo){

		$sql = "UPDATE articulo SET condicion='1' WHERE idarticulo='$idarticulo'";
		return ejecutarConsulta($sql);
	}

	//Implementar metodo para mostar registros
	public function mostrar($idarticulo){

		$sql = "SELECT * FROM articulo WHERE idarticulo='$idarticulo'";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros
	public function listar($idempresa){

		$sql = "SELECT a.idarticulo, a.idcategoria, c.nombre AS categoria, a.codigo, a.nombre, a.stock, a.descripcion, a.imagen, a.condicion, a.precio_venta, a.tipo FROM articulo a INNER JOIN categoria c ON a.idcategoria=c.idcategoria WHERE empresa_idempresa= '$idempresa' ORDER BY a.idarticulo DESC";
		return ejecutarConsulta($sql);
	}
	public function listarActivos($idempresa){

		$sql = "SELECT a.idarticulo, a.idcategoria, c.nombre AS categoria, a.codigo, a.nombre, a.stock, a.descripcion, a.imagen, a.condicion, a.precio_venta, a.tipo FROM articulo a INNER JOIN categoria c ON a.idcategoria=c.idcategoria WHERE a.condicion='1' AND empresa_idempresa= '$idempresa' ";
		return ejecutarConsulta($sql);
	}
	


}

 ?>