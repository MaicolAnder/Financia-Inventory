<?php 
require "../config/Conexion.php";
Class Ingreso{
	//Implementar constructor
	public function __constructor(){

	}

	//Implementar metodo para insertar registro
	public function insertar($idcliente, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_venta, $idempresa, $idarticulo, $cantidad, $precio_venta, $descuento ){

		$sql = "INSERT INTO venta (idcliente, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total_venta, estado, empresa_idempresa) VALUES ('$idcliente', '$idusuario', '$tipo_comprobante', '$serie_comprobante', '$num_comprobante', '$fecha_hora', '$impuesto', '$total_venta', 'Aceptado','$idempresa')";
		//return ejecutarConsulta($sql);
		//consulta que devuelve el id de ingreso y agrega los permisos
		$idingresonew = ejecutarConsulta_retornaID($sql);
		$num_elementos = 0;
		$sw=true;
		while ($num_elementos < count($idarticulo)) {
			$sql_detalle = "INSERT INTO detalle_venta(idventa, idarticulo, cantidad, precio_venta, descuento) VALUES('$idingresonew','$idarticulo[$num_elementos]', '$cantidad[$num_elementos]', '$precio_venta[$num_elementos]', '$descuento[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		}
		return $sw;
	}
	public function insertar_imprimir($idcliente, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_venta, $idempresa, $idarticulo, $cantidad, $precio_venta, $descuento ){

		$sql = "INSERT INTO venta (idcliente, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total_venta, estado, empresa_idempresa) VALUES ('$idcliente', '$idusuario', '$tipo_comprobante', '$serie_comprobante', '$num_comprobante', '$fecha_hora', '$impuesto', '$total_venta', 'Aceptado','$idempresa')";
		//return ejecutarConsulta($sql);
		//consulta que devuelve el id de ingreso y agrega los permisos
		$idingresonew = ejecutarConsulta_retornaID($sql);
		$num_elementos = 0;
		$sw=true;
		while ($num_elementos < count($idarticulo)) {
			$sql_detalle = "INSERT INTO detalle_venta(idventa, idarticulo, cantidad, precio_venta, descuento) VALUES('$idingresonew','$idarticulo[$num_elementos]', '$cantidad[$num_elementos]', '$precio_venta[$num_elementos]', '$descuento[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		}
		return $idingresonew or $sw = false;
	}
	
	//Implementar metodo para anular 
	public function anular($idventa){

		$sql = "UPDATE venta SET estado='Anulado' WHERE idventa='$idventa'";
		return ejecutarConsulta($sql);
	}
	
	//Implementar metodo para mostar cada uno de los registros
	public function mostrar($idventa){

		$sql = "SELECT v.idventa, date(v.fecha_hora) AS fecha, v.idcliente, p.nombre AS cliente, u.idusuario, u.nombre AS usuario, v.tipo_comprobante, v.serie_comprobante, v.num_comprobante, v.total_venta, v.impuesto, v.estado FROM venta v INNER JOIN persona p ON v.idcliente=p.idpersona INNER JOIN usuario u ON v.idusuario=u.idusuario WHERE v.idventa='$idventa'";
		return ejecutarConsultaSimpleFila($sql);
	}
	//Implementar metodo para listar  todos los registros
	public function listar($idempresa){

		$sql = "SELECT v.idventa, date(v.fecha_hora) AS fecha, v.idcliente, p.nombre AS cliente, u.idusuario, u.nombre AS usuario, v.tipo_comprobante, v.serie_comprobante, v.num_comprobante, v.total_venta, v.impuesto, v.estado FROM venta v INNER JOIN persona p ON v.idcliente=p.idpersona INNER JOIN usuario u ON v.idusuario=u.idusuario WHERE v.empresa_idempresa = '$idempresa' ORDER BY v.idventa DESC";
		return ejecutarConsulta($sql);
	}
	//Funcion sin funcionamiento 
	public function total_venta(){
		$sql = "SELECT SUM(total_venta) AS total_venta FROM venta";
		return ejecutarConsulta($sql);
	}
	public function detalle_articulosV($idventa){
		$sql = "SELECT dt.*, a.nombre AS articulo, dt.cantidad*dt.precio_venta AS total FROM detalle_venta AS dt INNER JOIN articulo AS a ON dt.idarticulo = a.idarticulo WHERE dt.idventa = '$idventa'";
		return ejecutarConsulta($sql);

	}
	public function detalle_datosV($idventa, $idempresa){
		$sql = "SELECT v.*, p.nombre As cliente, p.direccion As cliente_dir, p.telefono As tel_cliente, u.nombre AS venderdor, u.telefono AS tel_usu FROM venta AS v INNER JOIN persona AS p ON v.idcliente = p.idpersona INNER JOIN usuario AS u ON v.idusuario = u.idusuario WHERE v.empresa_idempresa = '$idempresa' AND v.idventa = '$idventa'";
		return ejecutarConsultaSimpleFila($sql);
	}
	
}

 ?>