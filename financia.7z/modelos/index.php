<?php 

ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
	header('location: ../web/ ');
	exit();
} 
else{
	header('location: ../app/articulo.php ');
  	exit();
} 
ob_end_flush(); 
?>