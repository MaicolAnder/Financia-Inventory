<?php 
require "../config/Conexion.php";
Class Permiso{
	//Implementar constructor
	public function __constructor(){

	}

	public function listar(){

		$sql = "SELECT * FROM permiso";
		return ejecutarConsulta($sql);
	}
	
}

 ?>