<?php 
	header('location: web/');
	exit();
 ?>