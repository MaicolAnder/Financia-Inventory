<?php 
//define la pc de base de datos
define("DB_HOST", "localhost");

//define nombre de base de datos
define("DB_NAME", "dbsistema");
//define usuario de base de datos
define("DB_USERNAME", "root");

//define la contraseña del usuario de base de datos
define("DB_PASSWORD", "");

//define codificacion de caracteres
define("DB_ENCODE", "utf8");

//define constante como nombre del proyecto
define("PRO_NOMBRE", "Ventas MAT");
 ?>