<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Usuario.php";

	$usuario = new Usuario();


	$idusuario=isset($_POST["idusuario"])?limpiarCadena($_POST["idusuario"]):"";
	$nombre=isset($_POST["nombre"])?limpiarCadena($_POST["nombre"]):"";
	$tipo_doc=isset($_POST["tipo_doc"])?limpiarCadena($_POST["tipo_doc"]):"";
	$num_doc=isset($_POST["num_doc"])?limpiarCadena($_POST["num_doc"]):"";
	$direccion=isset($_POST["direccion"])?limpiarCadena($_POST['direccion']):"";
	$telefono=isset($_POST["telefono"])?limpiarCadena($_POST["telefono"]):"";
	$cargo=isset($_POST["cargo"])?limpiarCadena($_POST["cargo"]):"";
	$login=isset($_POST["login"])?limpiarCadena($_POST["login"]):"";
	$clave=isset($_POST["clave"])?limpiarCadena($_POST['clave']):"";
	$usuario_admon=$_SESSION["usuario_admon"];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			//Subir y validar imagenes
			if ($_FILES ["imagen"]["error"] > 0){
	        	echo "Sin archivo de imagen";
	        }
	        if ( !file_exists($_FILES['imagen']["tmp_name"]) || !is_uploaded_file($_FILES['imagen']["tmp_name"])) 
			{
				$imagen = $_POST["imgactual"];
			} 
			else {
				//Optener extencion y validar extencion de la imagen 
				$ext = explode(".", $_FILES['imagen']['name']);
				if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/png" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/gif") 
				{
						$imagen = round(microtime(true)) . '.' . end($ext);
						move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/usuarios/".$imagen);
				} else{
					echo '<div class="alert alert-danger">No se actualizo imagen, archivo no valido.</div>';
				}
			}
			$clavehash = hash("SHA256", $clave);
			if (empty($idusuario)) {
				$rspta = $usuario->insertar($nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clavehash, $imagen, $usuario_admon, $_POST['permiso']);
				echo $rspta? '<div class="alert alert-success">Usuario registrado con exitos</div>' : '<div class="alert alert-danger">Usuario no registrado</div>';
			} else {
				$rspta = $usuario->editar($idusuario, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clavehash, $imagen, $_POST['permiso']);

				echo $rspta? '<div class="alert alert-success">Usuario actualizado correctamente </div>' : '<div class="alert alert-danger">Usuario no actualizado</div>';
			}
			
			break;

		case 'desactivar':
			$rspta = $usuario->desactivar($idusuario);
				echo $rspta? '<div class="alert alert-success">Usuario desactivado</div>' : '<div class="alert alert-danger">Usuario no desactivar';
			break;

		case 'activar':
			$rspta = $usuario->activar($idusuario);
				echo $rspta? '<div class="alert alert-success">Usuario activado</div>' : '<div class="alert alert-danger">Usuario no se pudo activar';
			break;

		case 'mostrar':
			$rspta = $usuario->mostrar($idusuario);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $usuario->listar($usuario_admon);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->condicion)?'<button class="btn btn-warning" onclick="mostrar('.$reg->idusuario.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-success" onclick="desactivar('.$reg->idusuario.')"><i class="fa fa-unlock" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->idusuario.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-danger" onclick="activar('.$reg->idusuario.')"><i class="fa fa-unlock-alt" aria-hidden="true"></i></button>',
					"1" => $reg->nombre,
					"2" => $reg->tipo_doc,
					"3" => $reg->num_doc,
					"4" => $reg->direccion,
					"5" => $reg->telefono,
					"6" => $reg->login,
					"7" => $reg->cargo,
					"8" => "<img src='../../files/usuarios/".$reg->imagen."' height='50px' width='50px'>",
					"9" => ($reg->condicion)?'<span class="label label-success">Activo</span>':'<span class="label label-warning">Inactivo</span>'
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
			
		case 'permisos':
			require_once "../modelos/Permiso.php";
			$permiso = new Permiso();
			$rspta = $permiso->listar();
			//Obtener los persmisos marcados
			$id = $_GET['id'];
			$marcados = $usuario->listarmarcados($id);
			//declarar el array para almacenar permisos
			$valores = array();
			//Almacenar los permisos asignados en el array
			while ($per = $marcados->fetch_object()) {
				array_push($valores, $per->idpermiso);
			}
			//Mostrar la lista de permisos en la vista
			while ($reg = $rspta->fetch_object()) 
			{
				$sw = in_array($reg->idpermiso, $valores)?'checked':'';
				echo '<li><label class="checkbox-inline"><input type="checkbox" '.$sw.' name="permiso[]" value="'.$reg->idpermiso.'">'.$reg->nombre.'</label></li>';
			}
			break;
		case 'salir':
			//Limpiar variables de session
			session_unset();
			//Destruir la sesión
			session_destroy();
			header('location: ../index.php ');
			exit();
			break;

		case 'listar_usuarios':
			require_once "../modelos/Persona.php";
			$persona = new Persona();
			$rspta = $usuario->listar($usuario_admon);
			while ($reg = $rspta->fetch_object()) {
				echo '<option value='.$reg->idusuario.'>'.$reg->num_doc.'  -  '.$reg->nombre.'</option>';
			}

			break;
	}
?>