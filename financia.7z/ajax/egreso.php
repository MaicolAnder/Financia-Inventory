<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Egreso.php";

	$egreso = new Egreso();

	$nombre=isset($_POST["fecha"])?limpiarCadena($_POST["fecha"]):"";
	$tipo_doc=isset($_POST["tipo_comprobante"])?limpiarCadena($_POST["tipo_comprobante"]):"";
	$num_doc=isset($_POST["num_doc"])?limpiarCadena($_POST["num_doc"]):"";
	$direccion=isset($_POST["concepto"])?limpiarCadena($_POST['concepto']):"";
	$telefono=isset($_POST["empleado"])?limpiarCadena($_POST["empleado"]):"";
	$cargo=isset($_POST["total_egreso"])?limpiarCadena($_POST["total_egreso"]):"";
	$idempresa=$_SESSION['idempresa'];
	$idusuario=$_SESSION['idusuario'];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			/*/Subir y validar imagenes
			if ($_FILES ["imagen"]["error"] > 0){
	        	echo "Sin archivo de imagen";
	        }
	        if ( !file_exists($_FILES['imagen']["tmp_name"]) || !is_uploaded_file($_FILES['imagen']["tmp_name"])) 
			{
				$imagen = $_POST["imgactual"];
			} 
			else {
				//Optener extencion y validar extencion de la imagen 
				$ext = explode(".", $_FILES['imagen']['name']);
				if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/png" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/gif") 
				{
						$imagen = round(microtime(true)) . '.' . end($ext);
						move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/usuarios/".$imagen);
				} else{
					echo '<div class="alert alert-danger">No se actualizo imagen, archivo no valido.</div>';
				}
			} */
			if (empty($idusuario)) {
				$rspta = $egreso->insertar($nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clavehash, $imagen, $usuario_admon, $_POST['permiso']);
				echo $rspta? '<div class="alert alert-success">Usuario registrado con exitos</div>' : '<div class="alert alert-danger">Usuario no registrado</div>';
			} else {
				$rspta = $egreso->editar($idusuario, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $cargo, $login, $clavehash, $imagen, $_POST['permiso']);

				echo $rspta? '<div class="alert alert-success">Usuario actualizado correctamente </div>' : '<div class="alert alert-danger">Usuario no actualizado</div>';
			}
			
			break;

		case 'desactivar':
			$rspta = $egreso->desactivar($idusuario);
				echo $rspta? '<div class="alert alert-success">Usuario desactivado</div>' : '<div class="alert alert-danger">Usuario no desactivar';
			break;

		case 'activar':
			$rspta = $egreso->activar($idusuario);
				echo $rspta? '<div class="alert alert-success">Usuario activado</div>' : '<div class="alert alert-danger">Usuario no se pudo activar';
			break;

		case 'mostrar':
			$rspta = $egreso->mostrar($idusuario);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $egreso->listar($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->estado=='Aceptado')?'<button class="btn btn-success" onclick="mostrar('.$reg->egreso.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.' <button class="btn btn-danger" onclick="anular('.$reg->egreso.')" tittle="Anular"><i class="fa fa-thumbs-down" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->egreso.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>',
					"1" => $reg->concepto,
					"2" => $reg->tipo_egreso,
					"3" => $reg->fecha,
					"4" => $reg->cantidad,
					"5" => $reg->total_egreso
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
		case 'listar_usuarios':
			$usuarios = $egreso->usuario_empresa($idusuario);
			while ($reg = $usuarios->fetch_object()) {
				echo '<option value='.$reg->idusuario.'>'.$reg->num_doc.'  -  '.$reg->nombre.'</option>';
			}
			break;
			
	}
?>