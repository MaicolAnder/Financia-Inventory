<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Ingreso.php";

	$ingreso = new Ingreso();


	$idingreso=isset($_POST["idingreso"])?limpiarCadena($_POST["idingreso"]):"";
	$idproveedor=isset($_POST["idproveedor"])?limpiarCadena($_POST["idproveedor"]):"";
	$idusuario=$_SESSION["idusuario"];
	$tipo_comprobante=isset($_POST["tipo_comprobante"])?limpiarCadena($_POST["tipo_comprobante"]):"";
	$serie_comprobante=isset($_POST["serie_comprobante"])?limpiarCadena($_POST['serie_comprobante']):"";
	$num_comprobante=isset($_POST["num_comprobante"])?limpiarCadena($_POST["num_comprobante"]):"";
	$fecha_hora=isset($_POST["fecha_hora"])?limpiarCadena($_POST["fecha_hora"]):"";
	$impuesto=isset($_POST["impuesto"])?limpiarCadena($_POST["impuesto"]):"";
	$total_compra=isset($_POST["total_compra"])?limpiarCadena($_POST["total_compra"]):"";
	$idempresa=$_SESSION['idempresa'];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			if (empty($idingreso)) {
				$rspta = $ingreso->insertar($idproveedor, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_compra, $idempresa, $_POST['idarticulo'], $_POST['cantidad'], $_POST['precio_compra'], $_POST['precio_venta']);
				echo $rspta? '<div class="alert alert-success">Ingreso registrado con exitos</div>' : '<div class="alert alert-danger">No se pudieron ingresar todos los datos</div>';
			} else {
				echo '<div class="alert alert-danger">Error de ingreso</div>';
			}
			break;

		case 'anular':
			$rspta = $ingreso->anular($idingreso);
				echo $rspta? '<div class="alert alert-success">Ingreso anulado</div>' : '<div class="alert alert-danger">Ingreso no anulado';
			break;

		case 'mostrar':
			$rspta = $ingreso->mostrar($ingreso);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $ingreso->listar($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->estado=='Aceptado')?'<button class="btn btn-success" onclick="mostrar('.$reg->idingreso.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.' <button class="btn btn-danger" onclick="anular('.$reg->idingreso.')" tittle="Anular"><i class="fa fa-thumbs-down" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->idingreso.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>',
					"1" => $reg->fecha,
					"2" => $reg->proveedor,
					"3" => $reg->usuario,
					"4" => $reg->tipo_comprobante,
					"5" => $reg->serie_comprobante. '-' .$reg->num_comprobante,
					"6" => $reg->total_compra,
					"7" => ($reg->estado=='Aceptado')?'<span class="label label-success">Aceptado</span>':'<span class="label label-warning">Anulado</span>'
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
		case 'selectProveedor':
			require_once "../modelos/Persona.php";
			$persona = new Persona();
			$rspta = $persona->listarp($idempresa);
			while ($reg = $rspta->fetch_object()) {
				echo '<option value='.$reg->idpersona.'>'.$reg->num_doc.' - '.$reg->nombre.'</option>';
			}
			break;

		case 'listarArticulos':
			require_once "../modelos/Articulo.php";
			$articulo = new Articulo();
			$rspta = $articulo->listarActivos($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => "<img src='../../files/articulos/".$reg->imagen."' height='50px' width='50px'>",
					"1" => $reg->nombre,
					"2" => $reg->codigo,
					"3" => $reg->stock,
					"4" => '<input type="number"  class="form-control" id="precio_ventaf'.$reg->idarticulo.'"  value="'.$reg->precio_venta.'" style="width:120px">',
					"5" => '<input type="number" class="form-control" id="precio_compraf'.$reg->idarticulo.'"  min="0" style="width:120px"> ',
					"6" => '<input type="number" class="form-control" id="cantidadf'.$reg->idarticulo.'" min="0" style="width:70px">',
					"7" => '<button class="btn btn-warning" onclick="agregarDetalle('.$reg->idarticulo.',\''.$reg->nombre.'\')"><span class="fa fa-plus"></span></button>'  
					

					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);

			break;
		case 'total_compra':
			$rspta = $ingreso->total_compra();
			$reg = $rspta->fetch_object();
			echo "Total: ";
			echo $reg->total_compra;
			
			break;
	}
?>