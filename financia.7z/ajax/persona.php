<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Persona.php";

	$persona = new Persona();

	$idpersona=isset($_POST["idpersona"])?limpiarCadena($_POST["idpersona"]):"";
	$tipo_persona=isset($_POST["tipo_persona"])?limpiarCadena($_POST["tipo_persona"]):"";
	$nombre=isset($_POST["nombre"])?limpiarCadena($_POST["nombre"]):"";
	$tipo_doc=isset($_POST["tipo_doc"])?limpiarCadena($_POST["tipo_doc"]):"";
	$num_doc=isset($_POST["num_doc"])?limpiarCadena($_POST["num_doc"]):"";
	$direccion=isset($_POST["direccion"])?limpiarCadena($_POST['direccion']):"";
	$telefono=isset($_POST["telefono"])?limpiarCadena($_POST["telefono"]):"";
	$email=isset($_POST["email"])?limpiarCadena($_POST['email']):"";
	$usuario_admon=$_SESSION['usuario_admon'];
	$idempresa=$_SESSION['idempresa'];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			if (empty($_POST["nombre"]) || empty($_POST["tipo_doc"]) || empty($_POST["num_doc"])) {
				echo '<div class="alert alert-danger">Faltan datos obligatorios</div>';
				exit();
			}
			if (empty($idpersona)) {
				$rspta = $persona->insertar($tipo_persona, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $email, $idempresa);
				echo $rspta? '<div class="alert alert-success">Persona registrada</div>' : '<div class="alert alert-danger">Persona no registrada</div>';
			} else {
				$rspta = $persona->editar($idpersona, $tipo_persona, $nombre, $tipo_doc, $num_doc, $direccion, $telefono, $email);

				echo $rspta? '<div class="alert alert-success">Persona actualizada <i class="fa fa-check-square" aria-hidden="true"></i>' : '<div class="alert alert-danger">Persona no actualizada</div>';
			}
			
			break;

		case 'eliminar':
			$rspta = $persona->eliminar($idpersona);
				echo $rspta? '<div class="alert alert-success">Persona eliminada</div>' : '<div class="alert alert-danger">Persona no se pudo eliminar</div>';
			break;

		case 'mostrar':
			$rspta = $persona->mostrar($idpersona);
			echo json_encode($rspta);
			break;
		
		case 'listarp':
			$rspta = $persona->listarp($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => '<button class="btn btn-success" onclick="mostrar('.$reg->idpersona.')"><i class="fa fa-search-plus" aria-hidden="true"></i></button>'.
						' <button class="btn btn-danger" onclick="eliminar('.$reg->idpersona.')"><i class="fa fa-trash" aria-hidden="true"></i></button>',
					"1" => $reg->nombre,
					"2" => $reg->tipo_doc,
					"3" => $reg->num_doc,
					"4" => $reg->telefono,
					"5" => $reg->email
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;

		case 'listarc':
			$rspta = $persona->listarc($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => '<button class="btn btn-success" onclick="mostrar('.$reg->idpersona.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>' . 
						' <button class="btn btn-danger" onclick="eliminar('.$reg->idpersona.')"><i class="fa fa-trash" aria-hidden="true"></i></button>',
					"1" => $reg->nombre,
					"2" => $reg->tipo_doc,
					"3" => $reg->num_doc,
					"4" => $reg->direccion,
					"5" => $reg->telefono,
					"6" => $reg->email
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
	}
?>