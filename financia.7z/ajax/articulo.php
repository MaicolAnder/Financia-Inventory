<?php
if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Articulo.php";

	$articulo = new Articulo();


	$idarticulo=isset($_POST["idarticulo"])?limpiarCadena($_POST["idarticulo"]):"";
	$idcategoria=isset($_POST["idcategoria"])?limpiarCadena($_POST["idcategoria"]):"";
	$codigo=isset($_POST["codigo"])?limpiarCadena($_POST["codigo"]):"";
	$nombre=isset($_POST["nombre"])?limpiarCadena($_POST["nombre"]):"";
	$stock=isset($_POST["stock"])?limpiarCadena($_POST["stock"]):"";
	$tipo=isset($_POST["tipo"])?limpiarCadena($_POST["tipo"]):"";
	$descripcion=isset($_POST["descripcion"])?limpiarCadena($_POST["descripcion"]):"";
	$imagen=isset($_POST["imagen"])?limpiarCadena($_POST['imagen']):"";
	$precio_venta=isset($_POST["precio_venta"])?limpiarCadena($_POST['precio_venta']):"";
	$idempresa=$_SESSION['idempresa'];
	$usuario_admon=$_SESSION['usuario_admon'];

	if (isset($_GET["op"]) || !empty($_GET["op"])) {
	switch ($_GET["op"]) {
		case 'guardaryeditar':
			//Subir y validar imagenes
			if ($_FILES ["imagen"]["error"] > 0){
	        	echo "Sin archivo de imagen";
	        }
	        if ( !file_exists($_FILES['imagen']["tmp_name"]) || !is_uploaded_file($_FILES['imagen']["tmp_name"])) 
			{
				$imagen = $_POST["imgactual"];
			} 
			else {
				//Optener extencion y validar extencion de la imagen 
				$ext = explode(".", $_FILES['imagen']['name']);
				if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/png" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/gif") 
				{
						$imagen = round(microtime(true)) . '.' . end($ext);
						move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/articulos/".$imagen);
				} else{
					echo '<div class="alert alert-danger">No se actualizo imagen, archivo no valido.</div>';
				}
			}
			if (empty($idarticulo)) {
				$rspta = $articulo->insertar($idcategoria,$codigo,$nombre,$stock,$descripcion,$imagen, $precio_venta, $tipo, $idempresa);
				echo $rspta? '<div class="alert alert-success">Articulo registrado con exitos</div>' : '<div class="alert alert-danger">Articulo no registrado f</div>'.$tipo;
			} else {
				$rspta = $articulo->editar($idarticulo,$idcategoria, $codigo, $nombre, $descripcion, $imagen, $precio_venta, $tipo);

				echo $rspta? '<div class="alert alert-success">Articulo actualizado correctamente </div>' : '<div class="alert alert-danger">Articulo no actualizado</div>';
			}
			
			break;

		case 'desactivar':
			$rspta = $articulo->desactivar($idarticulo);
				echo $rspta? '<div class="alert alert-success">Articulo desactivado</div>' : '<div class="alert alert-danger">Articulo no se pudo desactivar';
			break;

		case 'activar':
			$rspta = $articulo->activar($idarticulo);
				echo $rspta? '<div class="alert alert-success">Articulo activado</div>' : '<div class="alert alert-danger">Articulo no se pudo desactivar';
			break;

		case 'mostrar':
			$rspta = $articulo->mostrar($idarticulo);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $articulo->listar($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->condicion)?'<button class="btn btn-warning" onclick="mostrar('.$reg->idarticulo.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-success" onclick="desactivar('.$reg->idarticulo.')"><i class="fa fa-unlock" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->idarticulo.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-danger" onclick="activar('.$reg->idarticulo.')"><i class="fa fa-unlock-alt" aria-hidden="true"></i></button>',
					"1" => $reg->nombre,
					"2" => $reg->categoria,
					"3" => $reg->codigo,
					"4" => $reg->stock,
					"5" => $reg->precio_venta,
					"6" => $reg->tipo,
					"7" => "<img src='../../files/articulos/".$reg->imagen."' height='50px' width='50px'>",
					"8" => ($reg->condicion)?'<span class="label label-success">Activo</span>':'<span class="label label-warning">Inactivo</span>'

					/* Para mostrar el ID 
					"0" => $reg->idcategoria,
					"1" => $reg->nombre,
					"2" => $reg->descripcion,
					"3" => $reg->condicion */
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
			
		case 'selectCategoria':
			require_once "../modelos/Categoria.php";
			$categoria = new Categoria();
			$rspta = $categoria->select($usuario_admon);
			while ($reg = $rspta->fetch_object()) {
				echo '<option value='.$reg->idcategoria.'>'.$reg->nombre.'</option>';
			}
			break;
		}
	} 	else{
		header('location: ../app/factura/');
		exit();
	}
?>
