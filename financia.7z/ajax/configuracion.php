<?php 
	require_once "../modelos/Configuracion.php.php";

	$configuracion = new Configuracion();

	$rspta = $permiso->listar();
	//declarar un array
	$data = Array();
	while ($reg = $rspta->fetch_object()) {
		$data[] = array(
			"0" => $reg->nombre
			);
		}
		$results = array(
			"sEcho"=>1, //Información para el datatable
			"iTotalRecords"=>count($data), //Enviar total de registros al data table
			"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
			"aaData"=>$data );
		echo json_encode($results);
		break;

?>