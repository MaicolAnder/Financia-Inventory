<?php
	if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Factura.php";

	$factura = new Ingreso();


	$idventa=isset($_POST["idventa"])?limpiarCadena($_POST["idventa"]):"";
	$idcliente=isset($_POST["idcliente"])?limpiarCadena($_POST["idcliente"]):"";
	$idusuario=$_SESSION["idusuario"];
	$tipo_comprobante=isset($_POST["tipo_comprobante"])?limpiarCadena($_POST["tipo_comprobante"]):"";
	$serie_comprobante=isset($_POST["serie_comprobante"])?limpiarCadena($_POST['serie_comprobante']):"";
	$num_comprobante=isset($_POST["num_comprobante"])?limpiarCadena($_POST["num_comprobante"]):"";
	$fecha_hora=isset($_POST["fecha_hora"])?limpiarCadena($_POST["fecha_hora"]):"";
	$impuesto=isset($_POST["impuesto"])?limpiarCadena($_POST["impuesto"]):"";
	$total_venta=isset($_POST["total_venta"])?limpiarCadena($_POST["total_venta"]):"";
	$idempresa=$_SESSION['idempresa'];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			if (empty($idventa)) {
				$rspta = $factura->insertar($idcliente, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_venta, $idempresa, $_POST['idarticulo'], $_POST['cantidad'], $_POST['precio_venta'], $_POST['descuento']);
				echo $rspta? '<div class="alert alert-success">Articulos registrados con exitos</div>' : '<div class="alert alert-danger">No se pudieron ingresar todos los datos</div>';
			} else {
				echo '<div class="alert alert-danger">Error de ingreso</div>';
			}
			break;
		case 'guardar_imprimir':
			if (empty($idventa)) {
				$rspta = $factura->insertar_imprimir($idcliente, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $impuesto, $total_venta, $idempresa, $_POST['idarticulo'], $_POST['cantidad'], $_POST['precio_venta'], $_POST['descuento']);
				echo $rspta? '<div class="alert alert-success">Articulos registrados con exitos</div>' : '<div class="alert alert-danger">No se pudieron ingresar todos los datos</div>';
			} else {
				echo '<div class="alert alert-danger">Error de ingreso</div>';
			}
			break;

		case 'anular':
			$rspta = $factura->anular($idventa);
				echo $rspta? '<div class="alert alert-success">Ingreso anulado</div>' : '<div class="alert alert-danger">Ingreso no anulado';
			break;

		case 'mostrar':
			$rspta = $factura->mostrar($idventa);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $factura->listar($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->estado=='Aceptado')?'<button class="btn btn-success" onclick="mostrar('.$reg->idventa.','.$idempresa.')"><i class="fa fa-search" aria-hidden="true"></i></button>'.' <button class="btn btn-danger" onclick="anular('.$reg->idventa.')" tittle="Anular"><i class="fa fa-thumbs-down" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->idventa.','.$idempresa.')"><i class="fa fa-search" aria-hidden="true"></i></button>',
					"1" => $reg->fecha,
					"2" => $reg->cliente,
					"3" => $reg->usuario,
					"4" => $reg->tipo_comprobante,
					"5" => $reg->serie_comprobante. '-' .$reg->num_comprobante,
					"6" => $reg->total_venta,
					"7" => ($reg->estado=='Aceptado')?'<span class="label label-success">Aceptado</span>':'<span class="label label-warning">Anulado</span>'
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
		case 'selectCliente':
			require_once "../modelos/Persona.php";
			$persona = new Persona();
			$rspta = $persona->listarc($idempresa);
			while ($reg = $rspta->fetch_object()) {
				echo '<option value='.$reg->idpersona.'>'.$reg->num_doc.'  -  '.$reg->nombre.'</option>';
			}
			break;

		case 'listarArticulos':
			require_once "../modelos/Articulo.php";
			$articulo = new Articulo();
			$rspta = $articulo->listarActivos($idempresa);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => "<img src='../../files/articulos/".$reg->imagen."' height='50px' width='50px'>",
					"1" => $reg->nombre,
					"2" => $reg->categoria,
					"3" => $reg->codigo,
					"4" => $reg->stock,
					"5" => ($reg->condicion)?'<span class="label label-success">Activo</span>':'<span class="label label-warning">Inactivo</span>',
					"6" => '<input type="number" class="form-control" id="preciof'.$reg->idarticulo.'" min="0" style="width: 120px" value="'.$reg->precio_venta.'">',
					"7" => '<input type="number" class="form-control" id="cantidadf'.$reg->idarticulo.'" min="0" style="width: 80px" autofocus>',
					"8" => '<button class="btn btn-warning" onclick="agregarDetalle('.$reg->idarticulo.',\''.$reg->nombre.'\')"><span class="fa fa-plus"></span></button>'

					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);

			break;

		case 'detalle_datos_venta':
			$rspta = $factura->detalle_datosV($idventa, $idempresa);
			echo json_encode($rspta);

			break;
		case 'detalle_articulos_venta':
			$idventa = $_GET['idventa'];
			$rspta = $factura->detalle_articulosV($idventa);
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(
					"0" => $reg->articulo,
					"1" => '0',
					"2" => $reg->precio_venta,
					"3" => $reg->cantidad,
					"4" => $reg->total
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			# code...
			break;
		case 'total_venta':
			require_once "../modelos/Factura.php";
			$rspta = $factura->total_venta();
			$reg = $rspta->fetch_object();
			echo "Total: ";
			echo $reg->total_venta;
			
			break;
	}
?>