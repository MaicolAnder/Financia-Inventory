<?php
if (strlen(session_id())<1) 
    session_start();
	require_once "../modelos/Categoria.php";

	$categoria = new Categoria();

	$idcategoria=isset($_POST["idcategoria"])?limpiarCadena($_POST["idcategoria"]):"";
	$nombre=isset($_POST["nombrec"])?limpiarCadena($_POST["nombrec"]):"";
	$descripcion=isset($_POST["descripcionc"])?limpiarCadena($_POST["descripcionc"]):"";
	$usuario_admon=$_SESSION['usuario_admon'];

	switch ($_GET["op"]) {

		case 'guardaryeditar':
			if (empty($_POST["nombrec"])) {
				echo '<div class="alert alert-danger">No pueden haber campos vacios</div>';
				exit();
			}
			if (empty($idcategoria)) {
				$rspta = $categoria->insertar($nombre,$descripcion,$usuario_admon);
				echo $rspta? '<div class="alert alert-success">Categoria Registrada Correctamente <i class="fa fa-check-square" aria-hidden="true"></i>': "Error! Categoria no registrada";
			} else {
				$rspta = $categoria->editar($idcategoria,$nombre,$descripcion);

				echo $rspta? '<div class="alert alert-success">Categoria actualizada <i class="fa fa-check-square" aria-hidden="true"></i>' : "Categoria no actualizada";
			}
			
			break;

		case 'desactivar':
			$rspta = $categoria->desactivar($idcategoria);
				echo $rspta? "Categoria desactivada" : "Categoria no se pudo desactivar";
			break;

		case 'activar':
			$rspta = $categoria->activar($idcategoria);
				echo $rspta? "Categoria activada" : "Categoria no se pudo activar";
			break;

		case 'mostrar':
			$rspta = $categoria->mostrar($idcategoria);
			echo json_encode($rspta);
			break;
		
		case 'listar':
			$rspta = $categoria->listar($usuario_admon);
			//declarar un array
			$data = Array();
			while ($reg = $rspta->fetch_object()) {
				$data[] = array(

					"0" => ($reg->condicion)?'<button class="btn btn-warning" onclick="mostrar('.$reg->idcategoria.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-success" onclick="desactivar('.$reg->idcategoria.')"><i class="fa fa-unlock" aria-hidden="true"></i></button>':'<button class="btn btn-warning" onclick="mostrar('.$reg->idcategoria.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>'.
						' <button class="btn btn-danger" onclick="activar('.$reg->idcategoria.')"><i class="fa fa-unlock-alt" aria-hidden="true"></i></button>',
					"1" => $reg->nombre,
					"2" => $reg->descripcion,
					"3" => ($reg->condicion)?'<span class="label label-success">Activo</span>':'<span class="label label-warning">Inactivo</span>'

					/* Para mostrar el ID 
					"0" => $reg->idcategoria,
					"1" => $reg->nombre,
					"2" => $reg->descripcion,
					"3" => $reg->condicion */
					);
			}
			$results = array(
				"sEcho"=>1, //Información para el datatable
				"iTotalRecords"=>count($data), //Enviar total de registros al data table
				"iTotalDisplayRecords"=>count($data), //Enviar total de registros al visualizador 
				"aaData"=>$data );
			echo json_encode($results);
			break;
	}
?>