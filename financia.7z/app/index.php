<!DOCTYPE html>
<html>
<head>
	<title>Configurando</title>
	<script>
		function carga() {
		 setTimeout("document.getElementById('cargando').style. display = 'none'", 3000);
		}
		window.onload = carga;
		
	</script>
</head>
<body>
	<meta http-equiv="refresh" content="10" > 
	<div id="cargando" style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: white url(http://oasisfm.cl/oasisfm/imag/master/iconoCargando.gif) no-repeat center center"></div> 

<?php
session_start(); 
if ($_SESSION['nombre']) {
	require_once "../modelos/Configuracion.php";

	$configuracion = new Configuracion();

	$rspta = $configuracion->cargar_Config($_SESSION['idusuario']);
	$fetch = $rspta->fetch_object();
	if (isset($fetch)) {
		if ($fetch->InicioApp == "Default") {
			header('Refresh: 1; URL=factura/articulo.php');
			exit();
		}
		if ($fetch->InicioApp == "Contabilidad") {
			header("Refresh: 1; URL=contabilidad/ ");
			exit();
		}
	}
		

} else {
	header('location: ../');
	exit();
}

?>
</body>
</html>