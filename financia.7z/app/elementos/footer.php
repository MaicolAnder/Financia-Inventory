<!-- footer content -->
        <footer>
          <div class="pull-right">
            Financia.com | Contabilidad simplicada, facturación simple | By <a href="">Maicol A. Tunubalá</a>
          </div>
          <div class="clearfix"></div>
        </footer>