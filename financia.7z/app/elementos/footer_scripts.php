<?php if (strlen(session_id())<1) {
    session_start();
} else{
?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="../assets/js/jquery-1.12.3.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/jquery.dataTables.min.js"></script>
	<script src="../assets/js/dataTables.bootstrap.js"></script> 
	<script src="../assets/js/dataTables.buttons.min.js"></script>
	<script src="../assets/js/buttons.bootstrap.min.js"></script>
	<script src="../assets/js/jszip.min.js"></script>
	<script src="../assets/js/pdfmake.min.js"></script>
	<script src="../assets/js/vfs_fonts.js"></script>
	<script src="../assets/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="../../web/assets/js/bootbox.min.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap-select.min.js"></script>
    <script src="../assets/js/fastclick.js"></script>
    <script src="../assets/js/nprogress.js"></script>
    <script src="../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../assets/js/custom.min.js"></script>
    <script type="text/javascript" src="../elementos/fullScreen.js"></script>
<?php } ?>
