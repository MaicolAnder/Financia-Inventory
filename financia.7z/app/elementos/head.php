<!DOCTYPE html>
<html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $title; ?> | Financia</title>
	<link rel="shortcut icon" href="../../web/media/images/financia.ico">
	<link rel="stylesheet" href="../assets/css/font-awesome.min.css">
  	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
 	 <link rel="stylesheet" href="../assets/css/dataTables.bootstrap.min.css">
  	<link rel="stylesheet" href="../assets/css/buttons.bootstrap.min.css">
  	<link rel="stylesheet" href="../assets/css/bootstrap-select.min.css">  	
    <link href="../assets/css/nprogress.css" rel="stylesheet">
    <link href="../assets/css/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
    <link href="../assets/css/custom.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/flex.css">
  </head>
</head>