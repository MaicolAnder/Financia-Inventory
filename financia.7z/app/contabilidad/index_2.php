<?php
$title 	= 	"Contabilidad";
include 	'head.php'; ?>
<div class="col-md-2">
	<div>
		<p>footer</p>
	</div>
</div>
<div class="col-md-10">
	<div>
		<p>footer</p>
	</div>
</div>

</body>
</html>