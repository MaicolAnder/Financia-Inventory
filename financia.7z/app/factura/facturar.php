<?php
ob_start();
session_start();
$fecha = date("Y-m-d");
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Facturar";
  include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Facturar']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Ventas y facturación</h1>
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> +  
      <button class="btn btn-info" onclick="mostrarform(true)">Nueva Venta  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Cliente</th>
              <th>Vendedor</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Venta</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Cliente</th>
              <th>Vendedor</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Venta</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
        <strong id="total_venta_sum">Total: </strong>
      </div>

      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Generar nueva factura</h2>
        <form class="form" id="formulario" method="post"> 
          <div class="form-group col-lg56  col-md-5 col-sm-5 col-xs-10">
            <label class="control-label">Cliente(*)</label>
            <input type="hidden" name="idventa" id="idventa">
            <select id="idcliente" name="idcliente" class="form-control selectpicker" data-live-search="true" required>
            </select>
          </div>
          <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
            <label class="control-label">+</label>
            <button class="btn btn-success" type="button" data-toggle="modal" data-target="#ingresarnew">Nuevo</button>
          </div>
           <div class="form-group col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Tipo Comprobante(*)</label>
            <select id="tipo_comprobante" name="tipo_comprobante" class="form-control selectpicker" data-live-search="true" required>
              <option value="">-- Seleccione --</option>
              <option value="Remision">Remisión</option>
              <option value="Factura">Factura</option>
              <option value="Cobro">Cuenta de cobro</option>
              <option value="Cotizazcion">Cotización</option>
            </select>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Fecha(*)</label>
            <input type="date" class="form-control" name="fecha_hora" id="fecha_hora" required>
          </div>
         
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Serie</label>
            <input type="text" class="form-control" name="serie_comprobante" maxlength="7" id="serie_comprobante" placeholder="Serie" >
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Número</label>
            <input type="text" class="form-control" name="num_comprobante" maxlength="10" id="num_comprobante" placeholder="Número" required>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Impuesto(%)</label>
            <input type="text" class="form-control" name="impuesto" id="impuesto" placeholder="Impuesto">
          </div>
          <div class="form-group col-lg-3 col-md-12 col-sm-12 col-xs-12">
            <label class="control-label"><i class="fa fa-cart-plus" aria-hidden="true"></i></label><br>
            <a href="#myModal" data-toggle="modal">
              <button id="btnAgregarArt" type="button" class="btn btn-success"><i class="fa fa-cart-plus" aria-hidden="true"></i> Agregar Artículo</button>
            </a>
          </div>
          
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
              <thead style="background-color:#A5D6A7">
                <th><i class="fa fa-trash" aria-hidden="true"></th>
                <th>Artículo</th>
                <th style="width:160px">Precio Venta</th>
                <th style="width:80px">Descuento(%)</th>
                <th style="width:80px">Cantidad</th>
                <th style="width:160px">Sub Total</th>
                <th><i class="fa fa-refresh" aria-hidden="true"></i></th>
              </thead>
              <tfoot>
                <th colspan="4"></th>
                
                <th><h3>TOTAL</h3></th>
                <th colspan="2" >
                  <h1><span class="label label-danger" id="total" >$ 0.00</span></h1>
                  <input type="hidden" name="total_venta" id="total_venta"></th>
              </tfoot>

              
            </table>
            <p id="total_letras"></p>
            <hr>
          </div>
          <div class="form-group col-lg-9 col-md-9 col-sm-9 col-xs-12 " id="guardar" style="text-align:right">
             <button class="btn btn-warning" type="button" onclick="imprimir_guardar()" id="imprimir_g"><i class="fa fa-print" aria-hidden="true"></i> Guardar e imprimir</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <button class="btn btn-success" type="submit" id="Guardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> &nbsp;Guardar</button>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12 ">
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
     
     <!-- modals -->
     <div class="modal fade" id="ingresarnew" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content text-center">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="exampleModalLabel"><strong>Agregar Nuevo Cliente</strong></h4>
            </div>
            <div class="modal-body">
              <form method="post" id="frmCliente" class="container-fluid" >
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">Nombre(*)</label>
                    <input type="hidden" name="idpersona" id="idpersona">
                    <input type="hidden" name="tipo_persona" id="tipo_persona" value="Cliente">
                    <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre proveedor" required>
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">Tipo documento(*)</label>
                    <select class="form-control selectpicker" id="tipo_doc" name="tipo_doc" data-live-search="true" required>
                      <option value="">-- Selecione --</option>
                      <option value="CC">C.C</option>
                      <option value="TI">T.I</option>
                      <option value="NIT">NIT</option>
                    </select>
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">Número de documento(*)</label>
                    <input type="text" class="form-control" name="num_doc" id="num_doc" maxlength="20" required placeholder="Documento">
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">Dirección</label>
                    <input type="text" class="form-control" name="direccion" id="direccion" maxlength="70" placeholder="Dirección">
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">Teléfono</label>
                    <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Teléfono">
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label class="control-label">E-mail</label>
                    <input type="text" class="form-control" name="email" id="email" maxlength="50" placeholder="Dirección E-mail">
                  </div>
                  <small>(*) Datos obligatorios</small>
              </div> 
              <div class="modal-footer">
                <button type="button" class="btn btn-cdro btn-warning" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
                <button type="button" class="btn btn-cdro btn-success" onclick="ingresarnew()"><i class="fa fa-sign-in" aria-hidden="true"></i> Ingresar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <!-- factura de venta  -->
      <div id="formulariover" class="container-fluid">
        <div class="container" id="print">
          <div class="row">
            <div class="col-xs-4 col-md-4 col-lg-4 text-left">
              <h2><img alt="" src="logo.png" /> Logo aquí</h2>
            </div>
            <div class="col-xs-4 col-md-4 col-lg-4 text-center">
              <h2><strong><?php echo $_SESSION['nombre_empresa']; ?></strong></h2>
              <p>NiT: 1000000-1, Popayan Cauca<br>
              <small>Eslogan del negocio</small></p>
            </div>
            <div class="col-xs-4 col-md-4 col-lg-4 text-right"> 
              <h5><br><br>
                <strong>FACTURA:<input type="text" class="btn-link text-right" readonly id="numfactura" readonly></strong>
              </h5>
            </div>
          </div>
           <!-- Sección siguiente -->
          <div class="row">  
            <div class="col-md-4">
              <div class="">
                  <p><strong>Nombre:</strong><input type="text" readonly class="btn-link" readonly id="clientefac"><br>
                  Dirección: <input type="text" readonly class="btn-link" readonly id="cliente_dir"><br>
                  Tel.: <input type="text" readonly class="btn-link" readonly id="tel_cliente">
                  </p>
              </div>             
            </div>
            <div class="col-md-4">
               <div class="">
                  <p>Vendedor:<input type="text"  class="btn-link" readonly id="vendedorfac" name=""><br>
                    Tel.: <input type="text" class="btn-link" readonly id="tel_usufac" name=""><br>
                    Codigo: <input type="text" class="btn-link" readonly id="idusuariofac" name="">
                  </p>
                </div>
            </div>
            <div class="col-md-4">
              <div class="">
                <p>
                  Fecha:<br> <input type="text" class="btn-link" readonly id="fechafac" name=""><br>
                  <input type="text" class="btn-link" readonly id="comprobantefac" name="">
                </p>
              </div>
            </div>
          </div>
            <!-- fin de sección de datos del Cliente  
            Detalles de la factura aquí -->
            <style type="text/css">
              table td:nth-child(3) {
                text-align: right;
              }
              table td:nth-child(4) {
                text-align: right;
              }
              table td:nth-child(5) {
                text-align: right;
              }
              .table-condensed>tbody>tr>td, .table-condensed>tbody>tr>th, .table-condensed>tfoot>tr>td, .table-condensed>tfoot>tr>th, .table-condensed>thead>tr>td, .table-condensed>thead>tr>th {
                padding: 2px;
              }
              .btn-link {
                  font-weight: 400;
                  color: #000000;
                  border-radius: 0;
              }
            </style>
            <table class="table table-bordered table-striped table-hover table-condensed table-responsive" id="detalle_factura" style="width: 100%;">
              <thead>
                <td>Artículo</td>
                <td>Iva</td>
                <td>Precio</td>
                <td>Cant</td>
                <td>Sub Total</td>
              </thead>
              <tbody>              
              </tbody>
              <tfoot>
              </tfoot>
            </table>
            <table>
            <tbody>
              <td style="width:80% ">
                <small class="text-justify"><strong>Resolución:</strong> 1. Esta factura de venta se asimila en todos sus efectos legales a una letra de
                cambio según el artículo No. 671 y S.S. 772-774 del código de comercio. 
                2. En caso de mora se causara el interés autorizado por la ley.
                </small>
              </td>
              <td style="width:10%">
                <strong class="text-right">
                  <p>
                    Sub Total:<br>
                    Impuestos:<br>
                    <h4>Total:</h4>
                  </p>
                </strong>
              </td >
              <td style="width:10%">
                <strong class="text-right">
                  <p>
                    $0<br>
                    $0<br>
                    <h4><input type="text" class="btn-link text-right" id="total_ventafac"></h4>
                  </p>
                </strong>
              </td>
            </tbody>
          </table>
          <table style="width: 100%">
            <td>
              <div class="">
                <p>Información</p>
              </div>
              <div class="panel-body">
               <small>Agradecemos la confianza depositada en nuestra empresa
               <p>Gracias por preferirnos, impreso a través de financia.com, ander.misak@gmail.com</p></small>
              </div>
            </td>
            <td>
              <div class="">
                <p>Aceptación</p>
                <div class=" panel-body ">
                  <div class="col-xs-6">
                    <p><hr>Firma y sello Entregado</p>
                  </div>
                  <div class="col-xs-6">
                    <p><hr>Firma y sello Cliente</p>
                  </div>
                </div>
              </div>
            </td>
          </table>
                     
      </div>
      <div>
        <button class="btn btn-info " type="button" onclick="imprimir()"><i class="fa fa-print" aria-hidden="true"></i> Imprimir </button>
        <button class="btn btn-danger" onclick="cancelarform()" type="button" ><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
      </div>
    </div>
    <!-- modal -->
     <div class="modal fade" id="myModal" role="dialog" arial-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Selecciona un artículo</h4>
            </div>
            <div class="modal-body">
              <table  class="table table-striped table-bordered table-condensed table-hover table-responsive" id="tblarticulos" width="100%">
                <thead>
                  <th>Imagen</th>
                  <th>Nombre</th>
                  <th>Categoria</th>
                  <th>Código</th>
                  <th>Stock</th>
                  <th>Estado</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
                  <th>Agregar</th>
                </thead>
                <tbody>

                  
                </tbody>
                <tfoot>
                  <th>Imagen</th>
                  <th>Nombre</th>
                  <th>Categoria</th>
                  <th>Código</th>
                  <th>Stock</th>
                  <th>Estado</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
                  <th>Agregar</th>
                </tfoot>
              </table>              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
       
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/factura.js"></script>
<script type="text/javascript" src="../assets/js/jquery.PrintArea.js"></script>
<!-- <script type="text/javascript" src="scripts/numletras.js"></script> -->
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>
