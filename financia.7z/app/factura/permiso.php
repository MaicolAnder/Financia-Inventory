<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Permisos";
include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Permisos']==1) 
    { ?>

    <div class="right_col" role="main">
      <h1 class="page-header">Visor de permisos</h1>
      
      <div class="table-responsive well" id="listadoregistro">
      <h2 class="sub-header"> 
      </h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Nombre</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Nombre</th>
            </tr>
          </tfoot>
        </table>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/permiso.js"></script>
</body>
</html>

<?php 
} 
ob_end_flush(); 
?>
