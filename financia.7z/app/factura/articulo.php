<?php 

ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../../web/ ');
  exit();
} 
else{
 $title = "Artículo";
 $active = "active";

 include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
        if ($_SESSION['Articulos']==1) 
        { ?> 
    <div class="right_col" role="main">
      <h1 class="page-header">Adminstrador de artículos</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header">+ 
      <button class="btn btn-info" onclick="mostrarform(true)">Nuevo Producto / Servicio  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Categoria</th>
              <th>Código</th>
              <th>Stock</th>
              <th>Precio venta</th>
              <th>Tipo</th>
              <th>Imagen</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Categoria</th>
              <th>Código</th>
              <th>Stock</th>
              <th>Precio venta</th>
              <th>Tipo</th>
              <th>Imagen</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="modal fade" id="categorianew" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content text-center">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="exampleModalLabel"><strong> Nueva Categoria</strong></h4>
            </div>
            <form method="post" id="frmCategorianew" class="container-fluid">
              <div class="modal-body">
                <div class="form-group row">
                  <label for="nombre_cat" class="col-2 col-form-label">Nombre</label>
                  <div class="col-10">
                    <input class="form-control" type="text" name="nombrec" id="nombrec" placeholder="Nombre Categoria" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="descripcion" class="col-2 col-form-label">Descripción</label>
                  <div class="col-10">
                    <input type="text" class="form-control" id="descripcionc" name="descripcionc" placeholder="Descripción" required>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-cdro btn-warning" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
                <button type="submit" class="btn btn-cdro btn-success" onclick="categorianew()"><i class="fa fa-sign-in" aria-hidden="true" ></i> Agregar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Registro de artículo</h2>
        <form class="form" name="formulario" id="formulario" method="POST" enctype="multipart/form-data"> 
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Nombre(*)</label>
            <input type="hidden" name="idarticulo" id="idarticulo">
            <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre" required>
          </div>
          <div class="form-group col-lg-5 col-md-5 col-sm-5 col-xs-10">
            <label class="control-label">Categoria(*)</label>
            <select class="form-control selectpicker" id="idcategoria" name="idcategoria" data-live-search="true" required></select>
          </div>
          <div class="form-group col-lg-1 col-md-1 col-sm-1 col-xs-12">
            <label class="control-label">+</label>
            <button class="btn btn-success" type="button" data-toggle="modal" data-target="#categorianew">Nuevo</button>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Stock Actual</label>
            <input type="number" class="form-control" name="stock" id="stock" value="" required disabled>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Tipo Ingreso(*)</label>
            <select class="form-control" data-live-search="true" name="tipo" id="tipo" required>
              <option value="">-- Selecione --</option>
              <option value="Articulo">Artículo</option>
              <option value="Servicio">Servicio</option>
            </select>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Precio venta</label>
            <input type="number" class="form-control" min="0" name="precio_venta" id="precio_venta" required>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Descripción</label>
            <input type="text" class="form-control" name="descripcion" id="descripcion" maxlength="256" placeholder="descripcion">
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Imagen</label>
            <input type="file" class="form-control" name="imagen" id="imagen">
            <input type="hidden" name="imgactual" id="imgactual">
            <img src="" width="150px" height="150px" id="imgmuestra">
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Código</label>
            <input type="text" class="form-control" name="codigo" id="codigo">
            <div class="col-md-3 col-xs-12">
              <p></p>
              <button class="btn btn-success" type="button" onclick="generarbarcode()"><i class="fa fa-barcode" aria-hidden="true"></i> Generar</button>
              <button class="btn btn-info " type="button" onclick="imprimir()"><i class="fa fa-print" aria-hidden="true"></i> Imprimir </button>
            </div>
            <div id="print" class="col-md-9 col-xs-12">
              <svg id="barcode"></svg>
            </div>
          </div>
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr>
            <button class="btn btn-success" type="submit" id="btnGuardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="../assets/js/JsBarcode.all.min.js"></script>
<script type="text/javascript" src="../assets/js/jquery.PrintArea.js"></script>
<script type="text/javascript" src="scripts/articulo.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>