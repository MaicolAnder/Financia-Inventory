<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Facturar";
 include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include 'nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Facturar']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Ventas y facturación</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> +  
      <button class="btn btn-info" onclick="mostrarform(true)">Nueva Venta  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Cliente</th>
              <th>Vendedor</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Venta</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Cliente</th>
              <th>Vendedor</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Venta</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Generar nueva factura</h2>
        <form class="form" id="formulario" method="post"> 
          <div class="form-group col-lg56  col-md-5 col-sm-5 col-xs-10">
            <label class="control-label">Cliente(*)</label>
            <input type="hidden" name="idventa" id="idventa">
            <select id="idcliente" name="idcliente" class="form-control selectpicker" data-live-search="true" required>
            </select>
          </div>
          <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
            <label class="control-label">+</label>
            <button class="btn btn-success" type="button" onclick="location.href='cliente.php'">Nuevo</button>
          </div>
           <div class="form-group col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Tipo Comprobante(*)</label>
            <select id="tipo_comprobante" name="tipo_comprobante" class="form-control selectpicker" data-live-search="true" required>
              <option value="">-- Seleccione --</option>
              <option value="Remision">Remisión</option>
              <option value="Factura">Factura</option>
              <option value="Cobro">Cuenta de cobro</option>
              <option value="Cotizazcion">Cotización</option>
            </select>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Fecha(*)</label>
            <input type="date" class="form-control" name="fecha_hora" id="fecha_hora" required>
          </div>
         
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Serie</label>
            <input type="text" class="form-control" name="serie_comprobante" maxlength="7" id="serie_comprobante" placeholder="Serie" >
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Número</label>
            <input type="text" class="form-control" name="num_comprobante" maxlength="10" id="num_comprobante" placeholder="Número" required>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Impuesto</label>
            <input type="text" class="form-control" name="impuesto" id="impuesto" placeholder="Impuesto">
          </div>
          <div class="form-group col-lg-3 col-md-12 col-sm-12 col-xs-12">
            <label class="control-label"><i class="fa fa-cart-plus" aria-hidden="true"></i></label><br>
            <a href="#myModal" data-toggle="modal">
              <button id="btnAgregarArt" type="button" class="btn btn-success"><i class="fa fa-cart-plus" aria-hidden="true"></i> Agregar Artículo</button>
            </a>
          </div>
          
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
              <thead style="background-color:#A5D6A7">
                <th><i class="fa fa-trash" aria-hidden="true"></th>
                <th>Artículo</th>
                <th style="width:160px">Precio Venta</th>
                <th style="width:80px">Descuento(%)</th>
                <th style="width:80px">Cantidad</th>
                <th style="width:160px">Sub Total</th>
                <th><i class="fa fa-refresh" aria-hidden="true"></i></th>
              </thead>
              <tfoot>
                <th colspan="4"></th>
                
                <th><h3>TOTAL</h3></th>
                <th colspan="2" >
                  <h1><span class="label label-danger" id="total" >$ 0.00</span></h1>
                  <input type="hidden" name="total_venta" id="total_venta"></th>
              </tfoot>

              
            </table>
            <p id="total_letras"></p>
            <hr>
          </div>
          <div class="form-group col-lg-9 col-md-9 col-sm-9 col-xs-12 " id="guardar" style="text-align:right">
             <button class="btn btn-warning" type="button" onclick="imprimir()" id="imprimir"><i class="fa fa-print" aria-hidden="true"></i> Guardar e imprimir</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <button class="btn btn-success" type="submit" id="Guardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> &nbsp;Guardar</button>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12 ">
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
      <div id="formulariover" class="">
         <h1>Factura de venta</h1><hr>
         <div class="container col-xs-12 col-md-12 col-sm-12 col-lg-12">
          <div class="col-xs-6">
            <h1><a href=" "><img alt="" src="logo.png" /> Logo aquí </a></h1>
          </div>
          <div class="col-xs-6 text-right">
            <h1>FACTURA</h1>
            <h1><small><input class="btn btn-link" type="number" id="num_comprobantev" name=""></small></h1>
          </div>
          <hr />
           <!--  
          <pre>Sección siguiente
          </pre> -->
          <div class="row">
            <div class="col-xs-5">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4>De: <a href="#">Su Nombre</a></h4>
                </div>
                <div class="panel-body">Dirección
                  detalles
                  más detalles
                </div>
              </div>
            </div>
            <div class="col-xs-5 col-xs-offset-2 text-right">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4>Para : <a href="#">Nombre del Cliente</a></h4>
                </div>
                <div class="panel-body">Dirección
                  detalles
                  más detalles
                </div>
              </div>
            </div>
          </div>
            <!--<pre><!-- / fin de sección de datos del Cliente  
            Detalles de la factura aquí
            </pre> -->
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>
                  <h4>Servicio</h4>
                </th>
                <th>
                  <h4>Descripción</h4>
                </th>
                <th>
                  <h4>Hrs / Cantidad</h4>
                </th>
                <th>
                  <h4>Tarifa / Precio</h4>
                </th>
                <th>
                  <h4>Sub-Total</h4>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Artículo</td>
                <td><a href="#"> Título de su artículo aquí </a></td>
                <td class=" text-right ">-</td>
                <td class=" text-right ">200.00 €</td>
                <td class=" text-right ">200.00 €</td>
              </tr>
              <tr>
                <td>Plantilla de diseño</td>
                <td><a href="#"> Detalles del proyecto aquí </a></td>
                <td class="text-right">10</td>
                <td class="text-right ">75.00 €</td>
                <td class="text-right ">750.00 €</td>
              </tr>
              <tr>
                <td>Desarrollo</td>
                <td><a href="#"> Plugin WordPress </a></td>
                <td class="text-right ">5</td>
                <td class="text-right">50.00 €</td>
                <td class="text-right">250.00 €</td>
              </tr>
            </tbody>
          </table>
              <!--<pre>Sección Totales
              </pre> -->
          <div class="row text-right">
            <div class="col-xs-3 col-xs-offset-7">
              <strong>
              Sub Total:<br>
              Impuestos (IVA 21%):<br>
              Total:
              </strong>
            </div>
            <div class="col-xs-2">
              <strong>
              1,200.00 €<br>
              252.00 €<br>
              1,452.00 €
              </strong>
            </div>
          </div>
            <!--<pre>Sección detalles de pago</pre> -->
          <div class="row">
            <div class = "col-xs-5">
              datos bancarios
            </div>
            <div class="col-xs-7">
              datos de contacto
            </div>
          </div> 
          <div class="panel panel-info col-xs-5">
              <div class="panel-heading">
                <h4>Datos bancarios</h4>
              </div>
              <div class="panel-body">
               Su nombre
               Nombre del banco
               SWIFT: -------
               Número de cuenta: 12345678
               IBAN: ------
              </div>
          </div> 
          <div class="span col-xs-7">
            <div class="panel panel-info">
              <div class="panel-heading">
                <h4> Datos de contacto </h4>
                <div class=" panel-body ">
                  Email: usted@ejemplo.com
                  Móvil: +92123456789
                  Twitter: <a href="https://twitter.com/suTwitter">@suTwitter</a> |Suweb: <a href="http://www.suweb.com/author/usted">
                  http: //www. suweb.com/author/usted / </a>
                  <h4><small> El pago debe ser por transferencia bancaria</small> </h4>
                </div>
              </div>
            </div>
          </div> 
         
         <button class="btn btn-danger" onclick="cancelarform()" type="button" ><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
     </div>
    </div>
     
     <!-- Modal artículo -->
     <div class="modal fade" id="myModal" role="dialog" arial-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Selecciona un artículo</h4>
            </div>
            <div class="modal-body">
              <table  class="table table-striped table-bordered table-condensed table-hover table-responsive" id="tblarticulos" width="100%">
                <thead>
                  <th>Imagen</th>
                  <th>Nombre</th>
                  <th>Categoria</th>
                  <th>Código</th>
                  <th>Stock</th>
                  <th>Estado</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
                  <th>Agregar</th>
                </thead>
                <tbody>

                  
                </tbody>
                <tfoot>
                  <th>Imagen</th>
                  <th>Nombre</th>
                  <th>Categoria</th>
                  <th>Código</th>
                  <th>Stock</th>
                  <th>Estado</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
                  <th>Agregar</th>
                </tfoot>
              </table>              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
       
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/factura.js"></script>
<!-- <script type="text/javascript" src="scripts/numletras.js"></script> -->
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>
