<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Compras";
  include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Compras']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Administrador de compras</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> +  
      <button class="btn btn-info" onclick="mostrarform(true)">Nuevo Ingreso  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table table-responsive table-bordered table-condensed table-hover" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Proveerdor</th>
              <th>Usuario</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Compra</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Fecha</th>
              <th>Proveerdor</th>
              <th>Usuario</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Total Compra</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
        <strong id="total_compra_sum"></strong>
      </div>      
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Nuevo ingreso de compra</h2>
        <form class="form" id="formulario" method="post"> 
          <div class="form-group col-lg-5  col-md-5 col-sm-5 col-xs-10">
            <label class="control-label">Proveedor(*)</label>
            <input type="hidden" name="idingreso" id="idingreso">
            <select id="idproveedor" name="idproveedor" class="form-control selectpicker" data-live-search="true" required>
            </select>
          </div>
          <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
            <label class="control-label">+</label>
            <button class="btn btn-success" type="button" data-toggle="modal" data-target="#ingresarnew">Nuevo</button>
          </div>
           <div class="form-group col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Tipo Comprobante(*)</label>
            <select id="tipo_comprobante" name="tipo_comprobante" class="form-control selectpicker" data-live-search="true" required>
              <option value="">-- Seleccione --</option>
              <option value="Boleta">Boleta</option>
              <option value="Factura">Factura</option>
              <option value="Ticket">Ticket</option>
            </select>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Fecha(*)</label>
            <input type="date" class="form-control" name="fecha_hora" id="fecha_hora" required>
          </div>
         
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <label class="control-label">Serie</label>
            <input type="text" class="form-control" name="serie_comprobante" maxlength="7" id="serie_comprobante" placeholder="Serie" >
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Número</label>
            <input type="text" class="form-control" name="num_comprobante" maxlength="10" id="num_comprobante" placeholder="Número" required>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-6">
            <label class="control-label">Impuesto</label>
            <input type="text" class="form-control" name="impuesto" id="impuesto" placeholder="Impuesto">
          </div>
          <div class="form-group col-lg-3 col-md-12 col-sm-12 col-xs-12">
            <label class="control-label"><i class="fa fa-cart-plus" aria-hidden="true"></i></label><br>
            <a href="#myModal" data-toggle="modal">
              <button id="btnAgregarArt" type="button" class="btn btn-success"><i class="fa fa-cart-plus" aria-hidden="true"></i> Agregar Artículo</button>
            </a>
          </div>
          
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <table id="detalles" class="table table-responsive table-condensed">
              <thead style="background-color:#A5D6A7">
                <th><i class="fa fa-trash" aria-hidden="true"></th>
                <th>Artículo</th>
                <th style="width:160px">Precio Venta</th>
                <th style="width:160px">Precio Compra</th>
                <th style="width:120px">Cantidad</th>
                <th style="width:150px">Sub Total</th>
                <th><i class="fa fa-refresh" aria-hidden="true"></i></th>
              </thead>
              <tfoot>
                <th colspan="4"></th>
                <th>TOTAL.</th>                
                <th colspan="2" >
                  <h1><span class="label label-danger" id="total" >$ 0.00</span></h1>
                  <input type="hidden" name="total_compra" id="total_compra"></th>
              </tfoot>
            </table><hr>
          </div>
          <div class="form-group col-lg-9 col-md-9 col-sm-9 col-xs-12 " id="guardar" style="text-align:right"> 
            <button class="btn btn-success" type="submit" id="Guardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>            
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12 " id="guardar" style="text-align:right">
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
            
          </div>
        </form>
      </div>
     </div>
     <!-- modals -->
     <div class="modal fade" id="ingresarnew" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content text-center">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel"><strong>Agregar Nuevo Proveedor</strong></h4>
          </div>
          <div class="modal-body">
            <form method="post" id="frmProveedor" class="container-fluid" >
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">Nombre(*)</label>
                  <input type="hidden" name="idpersona" id="idpersona">
                  <input type="hidden" name="tipo_persona" id="tipo_persona" value="Proveedor">
                  <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre proveedor" required>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">Tipo documento(*)</label>
                  <select class="form-control selectpicker" id="tipo_doc" name="tipo_doc" data-live-search="true" required>
                    <option value="">-- Selecione --</option>
                    <option value="CC">C.C</option>
                    <option value="TI">T.I</option>
                    <option value="NIT">NIT</option>
                  </select>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">Número de documento(*)</label>
                  <input type="text" class="form-control" name="num_doc" id="num_doc" maxlength="20" required placeholder="Documento">
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">Dirección</label>
                  <input type="text" class="form-control" name="direccion" id="direccion" maxlength="70" placeholder="Dirección">
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">Teléfono</label>
                  <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Teléfono">
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label class="control-label">E-mail</label>
                  <input type="text" class="form-control" name="email" id="email" maxlength="50" placeholder="Dirección E-mail">
                </div>
                <small>(*) Datos obligatorios</small>
            </div> 
            <div class="modal-footer">
              <button type="button" class="btn btn-cdro btn-warning" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
              <button type="button" class="btn btn-cdro btn-success" onclick="ingresarnew()"><i class="fa fa-sign-in" aria-hidden="true"></i> Ingresar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
     <div class="modal fade" id="myModal" role="dialog" arial-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Selecciona artículo a ingresar </h4>
            </div>
            <div class="modal-body">
              <table  class="table table-striped table-bordered table-condensed table-hover table-responsive" id="tblarticulos" width="100%">
                <thead>
                  <th>Imagen </th>
                  <th>Nombre </th>
                  <th>Código </th>
                  <th>Stock </th>
                  <th>Precio venta </th>
                  <th>Costo compra </th>
                  <th>Cantidad</th>
                  <th>Agregar </th>
                </thead>
                <tbody>
                  
                </tbody>
                <tfoot>
                  <th>Imagen </th>
                  <th>Nombre </th>
                  <th>Código </th>
                  <th>Stock </th>
                  <th>Precio venta </th>
                  <th>Costo compra </th>
                  <th>Cantidad</th>
                  <th>Agregar </th>
                </tfoot>
              </table>              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
       
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/ingreso.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>
