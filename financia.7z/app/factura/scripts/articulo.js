var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	})

	/*Cargar item para select de categoria */
	$.post("../../ajax/articulo.php?op=selectCategoria", function(r){
		$("#idcategoria").html(r);
		$("#idcategoria").selectpicker('refresh');
	});
	$("#imgmuestra").hide();
}

/*Funcion limpiar */
function limpiar()
{
	$("#codigo").val("");
	$("#nombre").val("");
	$("#descripcion").val("");
	$("#stock").val("");
	$("#precio_venta").val("");
	$("#imgmuestra").attr("src","");//Dejar vacio atributo
	$("#imgactual").val("");
	$("#print").hide(); //Ocultar el id del div
	$("#idarticulo").val("");
} 
//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/articulo.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación de la tabla
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/articulo.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			tabla.ajax.reload();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idarticulo){
	$.post("../../ajax/articulo.php?op=mostrar",{idarticulo : idarticulo}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		$("#idcategoria").val(data.idcategoria);
		$('#idcategoria').selectpicker('refresh');
		$("#codigo").val(data.codigo);
		$("#stock").val(data.stock);
		$("#precio_venta").val(data.precio_venta);
		$("#descripcion").val(data.descripcion);
		$("#imgmuestra").show();
		$("#imgmuestra").attr("src","../../files/articulos/"+data.imagen);
		$("#imgactual").val(data.imagen);
		$("#idarticulo").val(data.idarticulo);
		$("#nombre").val(data.nombre);
		$("#tipo").val(data.tipo);
		generarbarcode()
	})
}
function desactivar(idarticulo){
	bootbox.confirm("¿Esta seguro de desactivar articulo?", function(result){
		if (result) {
			$.post("../../ajax/articulo.php?op=desactivar",{idarticulo : idarticulo}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function activar(idarticulo){
	bootbox.confirm("¿Esta seguro de activar articulo?", function(result){
		if (result) {
			$.post("../../ajax/articulo.php?op=activar",{idarticulo : idarticulo}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
//Generar codigo de barras e imprimir codigo de barras
function generarbarcode(){
	codigo = $("#codigo").val();
	JsBarcode("#barcode", codigo);
	$("#print").show();

}
function imprimir(){
	$("#print").printArea();
}
function categorianew(e){
	var formData = new FormData($("#frmCategorianew")[0]);
	$.ajax({
		url: '../../ajax/categoria.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			$.post("../../ajax/articulo.php?op=selectCategoria", function(r){
				$("#idcategoria").html(r);
				$("#idcategoria").selectpicker('refresh');
			});
			$('#categorianew').modal('hide');
			mostrarform(true);
		} 
	});	
}

init();