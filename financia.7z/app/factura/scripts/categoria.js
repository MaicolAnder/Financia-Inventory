var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	})
}

/*Funcion limpiar */
function limpiar()
{
	$("#idcategoria").val("");
	$("#nombrec").val("");
	$("#descripcionc").val("");
} 
//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
		//$("#btnAgregar").hide ->Mostrar boton
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesaminto de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/categoria.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/categoria.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			tabla.ajax.reload();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idcategoria){
	$.post("../../ajax/categoria.php?op=mostrar",{idcategoria : idcategoria}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		$("#idcategoria").val(data.idcategoria);
		$("#nombrec").val(data.nombre);
		$("#descripcionc").val(data.descripcion);
	})
}
function desactivar(idcategoria){
	bootbox.confirm("¿Esta seguro de desactivar la categoria?", function(result){
		if (result) {
			$.post("../../ajax/categoria.php?op=desactivar",{idcategoria : idcategoria}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function activar(idcategoria){
	bootbox.confirm("¿Esta seguro de activar la categoria?", function(result){
		if (result) {
			$.post("../../ajax/categoria.php?op=activar",{idcategoria : idcategoria}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}


init();