var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	})
}

/*Funcion limpiar */
function limpiar()
{
	$("#tipo_doc").val("");
	$("#nombre").val("");
	$("#num_doc").val("");
	$("#direccion").val("");
	$("#telefono").val("");
	$("#email").val("");
	$("#idpersona").val("");
} 
//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
		//$("#btnAgregar").hide() ->Mostrar boton
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
		//$("#btnAgregar").show() ->Mostrar boton
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesaminto de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/persona.php?op=listarc',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/persona.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			tabla.ajax.reload();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idpersona){
	$.post("../../ajax/persona.php?op=mostrar",{idpersona : idpersona}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		
		$("#nombre").val(data.nombre);
		$("#tipo_doc").val(data.tipo_doc);
		$("#tipo_doc").selectpicker('refresh');
		$("#num_doc").val(data.num_doc);
		$("#direccion").val(data.direccion);
		$("#telefono").val(data.telefono);
		$("#email").val(data.email);
		$("#idpersona").val(data.idpersona);
	})
}
function eliminar(idpersona){
	bootbox.confirm("¿Esta seguro de eliminar el proveedor?", function(result){
		if (result) {
			$.post("../../ajax/persona.php?op=eliminar",{idpersona : idpersona}, function(t){
				bootbox.alert(t);
				tabla.ajax.reload();
			});
		}
	})
}
init();