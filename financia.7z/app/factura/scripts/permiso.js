var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();
}
//Funcion mostrar formulario
function mostrarform(flag){
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
		//$("#btnAgregar").hide ->Mostrar boton
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}
//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesaminto de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/permiso.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
init();