var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	})
	$("#imgmuestra").hide();
	$.post("../../ajax/usuario.php?op=permisos&id=", function(r)
	{
		$("#permisos").html(r);
		
	});
}

/*Funcion limpiar */
function limpiar()
{
	$("#nombre").val("");
	$("#num_doc").val("");
	$("#direccion").val("");
	$("#telefono").val("");
	$("#email").val("");
	$("#cargo").val("");
	$("#login").val("");
	$("#clave").val("");
	$("#imgmuestra").attr("src","");//Dejar vacio atributo
	$("#imgactual").val("");
	$("#idusuario").val("");
} 
//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/usuario.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/usuario.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			tabla.ajax.reload();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idusuario){
	$.post("../../ajax/usuario.php?op=mostrar",{idusuario : idusuario}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		$("#nombre").val(data.nombre);
		$("#tipo_doc").val(data.tipo_doc);
		$("#tipo_doc").selectpicker('refresh');
		$("#num_doc").val(data.num_doc);
		$("#direccion").val(data.direccion);
		$("#telefono").val(data.telefono);
		$("#cargo").val(data.cargo);
		$("#login").val(data.login)
		$("#clave").val("");
		$("#imgmuestra").show();
		$("#imgmuestra").attr("src","../../files/usuarios/"+data.imagen);
		$("#imgactual").val(data.imagen);
		$("#idusuario").val(data.idusuario);
	});
	$.post("../../ajax/usuario.php?op=permisos&id="+idusuario, function(r)
	{
		$("#permisos").html(r);
		
	});
}
function desactivar(idusuario){
	bootbox.confirm("¿Esta seguro de desactivar el usuario?", function(result){
		if (result) {
			$.post("../../ajax/usuario.php?op=desactivar",{idusuario : idusuario}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function activar(idusuario){
	bootbox.confirm("¿Esta seguro de activar el usuario?", function(result){
		if (result) {
			$.post("../../ajax/usuario.php?op=activar",{idusuario : idusuario}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}

init()