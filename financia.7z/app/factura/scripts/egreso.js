var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	})
}

/*Funcion limpiar */
function limpiar()
{
	$("#det_concepto").val("");
	$("#fecha").val("");
	$("#tipo_comprobante").val("");
	$("#concepto").val("");
	$("#empleado").val("");
	$("#total_egreso").val("");
	$("#idusuario").val("");
} 
//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/egreso.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength": 5, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/egreso.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			tabla.ajax.reload();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idusuario){
	$.post("../../ajax/egreso.php?op=mostrar",{idusuario : idusuario}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		$("#nombre").val(data.nombre);
		$("#tipo_doc").val(data.tipo_doc);
		$("#tipo_doc").selectpicker('refresh');
		$("#num_doc").val(data.num_doc);
		$("#direccion").val(data.direccion);
		$("#telefono").val(data.telefono);
		$("#cargo").val(data.cargo);
		$("#login").val(data.login)
		$("#clave").val("");
		$("#imgmuestra").show();
		$("#imgmuestra").attr("src","../../files/usuarios/"+data.imagen);
		$("#imgactual").val(data.imagen);
		$("#idusuario").val(data.idusuario);
	});
	$.post("../../ajax/egreso.php?op=permisos&id="+idusuario, function(r)
	{
		$("#permisos").html(r);
		
	});
}
function desactivar(idusuario){
	bootbox.confirm("¿Esta seguro de desactivar el egreso?", function(result){
		if (result) {
			$.post("../../ajax/egreso.php?op=desactivar",{idusuario : idusuario}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function activar(idusuario){
	bootbox.confirm("¿Esta seguro de activar el egreso?", function(result){
		if (result) {
			$.post("../../ajax/egreso.php?op=activar",{idusuario : idusuario}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}


$("#concepto").change(mostrar_usuario);
$('#empleados').hide();
function mostrar_usuario(){ 
	var item_selected=$("#concepto option:selected").text();
	if (item_selected=='Nomina') {
		$('#empleados').show();
        $('#empleado').prop('disabled', false);
		$.post("../../ajax/egreso.php?op=listar_usuarios", function(r){
			$("#empleado").html(r);
			$("#empleado").selectpicker('refresh');
		});
      }else{
        $('#empleado').prop('disabled', 'disabled');
        $('#empleados').hide();

      }

} 

init()