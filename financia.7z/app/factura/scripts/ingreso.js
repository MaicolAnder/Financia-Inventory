var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	});
	/*Cargar item para select de proveedor */
	$.post("../../ajax/ingreso.php?op=selectProveedor", function(r){
		$("#idproveedor").html(r);
		$("#idproveedor").selectpicker('refresh');
	});
	/* Cargar total compra */
	$.post("../../ajax/ingreso.php?op=total_compra", function(r){
		$("#total_compra_sum").html(r);
	});


}

/*Funcion limpiar */
function limpiar()
{
	$("#idproveedor").val("");
	$("#proveedor").val("");
	$("#serie_comprobante").val("");
	$("#num_comprobante").val("");
	$("#fecha_hora").val("");
	$("#impuesto").val("");

	$("#total_compra").val("");
	$(".filas").remove();
	$("#total").html("0");

}

//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
		listarArticulos();
		$("#guardar").hide();
		$("#btnGuardar").show();
		$("#btnCancelar").show();
		$("#btnAgregarArt").show();
		
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
	}
}

//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/ingreso.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength":8, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	//$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/ingreso.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			listar();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idarticulo){
	$.post("../../ajax/articulo.php?op=mostrar",{idarticulo : idarticulo}, function(data, status)
	{
		data = JSON.parse(data);
		mostrarform(true); //mostrar el form y Envio datos al formulario
		$("#idcategoria").val(data.idcategoria);
		$('#idcategoria').selectpicker('refresh');
		$("#codigo").val(data.codigo);
		$("#nombre").val(data.nombre);
		$("#stock").val(data.stock);
		$("#descripcion").val(data.descripcion);
		$("#imgmuestra").show();
		$("#imgmuestra").attr("src","../../files/articulos/"+data.imagen);
		$("#imgactual").val(data.imagen);
		$("#idarticulo").val(data.idarticulo);
		generarbarcode()
	})
}
function anular(idingreso){
	bootbox.confirm("¿Esta seguro de anular el ingreso?", function(result){
		if (result) {
			$.post("../../ajax/ingreso.php?op=anular",{idingreso : idingreso}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function listarArticulos(){
	tabla=$('#tblarticulos').dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					
				],
		"ajax": {
			url: '../../ajax/ingreso.php?op=listarArticulos',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength":8, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
//Variables para compras y detalles
var impuesto=19;
var cont=0;
var detalles=0;
$("#guardar").hide();
$("#tipo_comprobante").change(marcarImpuesto);
function marcarImpuesto(){ //funcion para cambiar la selección
	var tipo_comprobante=$("#tipo_comprobante option:selected").text();
	if (tipo_comprobante=='Factura') {
		$("#impuesto").val(impuesto);
	} else {
		$("#impuesto").val("0");
	}
}
function agregarDetalle(idarticulo, articulo){

	var cantidadf = document.getElementById("cantidadf"+idarticulo);
	var precio_compraf = document.getElementById("precio_compraf"+idarticulo);
	var precio_ventaf = document.getElementById("precio_ventaf"+idarticulo);
	var cantidad = cantidadf.value;
	var precio_compra = precio_compraf.value;
	var precio_venta = precio_ventaf.value;

	if (idarticulo!="") {
		var subtotal = cantidad*precio_compra;
		var fila = 	'<tr class="filas" id="fila'+cont+'">'+
					'<td><button class="btn btn-danger" onclick="eliminarDetalle('+cont+')"><i class="fa fa-trash" aria-hidden="true"></i></button></td>'+
					'<td><input class="form-control" type="hidden" name="idarticulo[]" value="'+idarticulo+'">'+articulo+'</td>'+
					'<td><input class="form-control" type="number" name="precio_venta[]" id="precio_venta[]" value="'+precio_venta+'"></td>'+
					'<td><input class="form-control" type="number" name="precio_compra[]" id="precio_compra[]" value="'+precio_compra+'"></td>'+
					'<td><input class="form-control" type="number" name="cantidad[]" id="cantidad[]" value="'+cantidad+'"></td>'+
					'<td><span class="control-label" name="subtotal" id="subtotal'+cont+'" >'+subtotal+'</span></td>'+
					'<td><button type="button" onclick="modSubtotales()" class="btn btn-info"><i class="fa fa-refresh" aria-hidden="true"></i></button></td>'+
					'<tr>';
		cont++;
		detalles=detalles+1;
		$("#detalles").append(fila);
		modSubtotales();
	} else {
		alert("Error al ingresar detalle");
	}
}
function modSubtotales(){
	var cant = document.getElementsByName("cantidad[]");
	var prec = document.getElementsByName("precio_compra[]");
	var sub  = document.getElementsByName("subtotal");

	for (var i = 0; i <cant.length; i++) {
		var inpC = cant[i];	//Cantidad
		var inpP = prec[i]; //Precio_compra
		var inpS = sub[i];  //Subtotal

		inpS.value=inpC.value * inpP.value;
		document.getElementsByName("subtotal")[i].innerHTML = inpS.value;
	}
	calcularTotales();
}
function calcularTotales(){
	var sub = document.getElementsByName("subtotal");
	var total = 0.0;
	for (var i = 0; i < sub.length; i++) {
		total += document.getElementsByName("subtotal")[i].value;
	}
	$("#total").html("$ " + total);
	$("#total_compra").val(total);
	evaluar();
}
function evaluar(){
	if (detalles > 0) {
		$("#guardar").show();
	} else {
		$("#guardar").hide();
		cont=0;
	}
}
function eliminarDetalle(indice){
	$("#fila"+indice).remove();
	calcularTotales();
	detalles=detalles-1;
}
function ingresarnew(e){
	//e.preventDefault(); //No se activara la accion predeterminada del evento
	//$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#frmProveedor")[0]);
	$.ajax({
		url: '../../ajax/persona.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			/*Cargar item para select de proveedor */
			$.post("../../ajax/ingreso.php?op=selectProveedor", function(r){
				$("#idproveedor").html(r);
				$("#idproveedor").selectpicker('refresh');
			});
			$('#ingresarnew').modal('hide');
			mostrarform(true);
		} 
	});
	limpiar();
}
init();