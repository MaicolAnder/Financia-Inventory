var tabla;

//funcion que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();

	$("#formulario").on("submit", function(e)
	{
		guardaryeditar(e);
	});
	/*Cargar item para select de proveedor */
	$.post("../../ajax/factura.php?op=selectCliente", function(r){
		$("#idcliente").html(r);
		$("#idcliente").selectpicker('refresh');
	});

	/* Cargar total venta */
	$.post("../../ajax/factura.php?op=total_venta", function(r){
		$("#total_venta_sum").html(r);
	});


}

/*Funcion limpiar */
function limpiar()
{
	$("#idcliente").val("");
	$("#cliente").val("");
	$("#serie_comprobante").val("");
	$("#num_comprobante").val("");
	$("#fecha_hora").val("");
	$("#impuesto").val("");

	$("#total_venta").val("");
	$(".filas").remove();
	$("#total").html("0");

}

//Funcion mostrar formulario
function mostrarform(flag){
	limpiar();
	if (flag) {
		$("#listadoregistro").hide();
		$("#formularioregistro").show();
		$("#btnGuardar").prop("disable",false);
		listarArticulos();
		$("#guardar").hide();
		$("#btnGuardar").show();
		$("#btnCancelar").show();
		$("#btnAgregarArt").show();
	} else{
		$("#listadoregistro").show();
		$("#formularioregistro").hide();
		$("#formulariover").hide();
	}
}


//funcion cancelar form
function cancelarform(){
	limpiar();
	mostrarform(false);
}

//funcion listar
function listar(){
	tabla=$("#tbllistado").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					'copyHtml5',
					'excelHtml5',
					'csvHtml5',
					'pdf'
				],
		"ajax": {
			url: '../../ajax/factura.php?op=listar',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength":8, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function guardaryeditar(e){
	e.preventDefault(); //No se activara la accion predeterminada del evento
	//$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/factura.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrarform(false);
			listar();
		} 
	});
	limpiar();
}

//Funcion mostrar para poder editar
function mostrar(idventa, idempresa){
	$.post("../../ajax/factura.php?op=detalle_datos_venta",{idventa : idventa, idempresa : idempresa}, function(data, status)
	{
		listar_detalle_fac(idventa);
		data = JSON.parse(data);
		$("#listadoregistro").hide();
		$("#formularioregistro").hide();
		$("#formulariover").show();		
		$("#btnCancelar").show();
		//mostrarformv(true); /* mostrar el form y Envio datos al formulario
		
		$("#clientefac").val(data.cliente)
		$("#cliente_dir").val(data.cliente_dir);
		$("#tel_cliente").val(data.tel_cliente);
		//Usuario
		$("#vendedorfac").val(data.venderdor);
		$("#tel_usufac").val(data.tel_usu);
		$("#idusuariofac").val(data.idusuario);

		//factura
		$("#estadofac").val(data.estado);
		$("#fechafac").val(data.fecha_hora);
		$("#impuestofac").val(data.impuesto);
		$("#numfactura").val(data.serie_comprobante +"-"+ data.num_comprobante);
		$("#comprobantefac").val(data.tipo_comprobante);
		$("#total_ventafac").val(data.total_venta);

		
	})
}
function listar_detalle_fac(idventa){
	tabla=$("#detalle_factura").dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'rt', //Definimos los elementos de control de la tabla
		"ajax": {
			data: idventa,
			url: '../../ajax/factura.php?op=detalle_articulos_venta&idventa='+idventa,
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength":500, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
function anular(idventa){
	bootbox.confirm("¿Esta seguro de anular la factura?", function(result){
		if (result) {
			$.post("../../ajax/factura.php?op=anular",{idventa : idventa}, function(e){
				bootbox.alert(e);
				tabla.ajax.reload();
			});
		}
	})
}
function listarArticulos(){
	tabla=$('#tblarticulos').dataTable(
	{
		"aProcessing": true, //Activamos procesamiento de datatabes
		"aServerSide": true, //Paginación y filtrado realizados por el servidor
		dom: 'Bfrtip', //Definimos los elementos de control de la tabla
		buttons:[
					
				],
		"ajax": {
			url: '../../ajax/factura.php?op=listarArticulos',
			type: "get",
			dataType : "json",
			error: function(e){
				console.log(e.responseText);
			}
		},
	"bDestroy": true,
	"iDisplayLength":8, //paginación
	"order": [[ 0,"desc" ]] // Columna, Orden
	}).DataTable();
}
//Variables para compras y detalles
var impuesto=19;
var cont=0;
var detalles=0;
$("#guardar").hide();
$("#tipo_comprobante").change(marcarImpuesto);
function marcarImpuesto(){ //funcion para cambiar la selección
	var tipo_comprobante=$("#tipo_comprobante option:selected").text();
	if (tipo_comprobante=='Factura') {
		$("#impuesto").val(impuesto);
	} else {
		$("#impuesto").val("0");
	}
}
function agregarDetalle(idarticulo, articulo){
	var cantidadf = document.getElementById("cantidadf"+idarticulo);
	var preciof = document.getElementById("preciof"+idarticulo);
	var cantidad = cantidadf.value;
	var precio_venta = preciof.value;
	var descuento = 0;

	if (idarticulo!="") {
		var subtotal = cantidad*precio_venta;
		var fila = 	'<tr class="filas" id="fila'+cont+'">'+
					'<td><button class="btn btn-danger" onclick="eliminarDetalle('+cont+')"><i class="fa fa-trash" aria-hidden="true"></i></button></td>'+
					'<td><input class="form-control" type="hidden" name="idarticulo[]" value="'+idarticulo+'">'+articulo+'</td>'+
					'<td><input class="form-control" type="number" name="precio_venta[]" id="precio_venta[]" value="'+precio_venta+'" min="0"></td>'+
					'<td><input class="form-control" type="number" name="descuento[]" id="descuento[]" value="'+descuento+'" min="0"></td>'+
					'<td><input class="form-control" type="number" name="cantidad[]" id="cantidad[]" value="'+cantidad+'"  min="0" autofocus></td>'+
					'<td><span class="control-label" name="subtotal" id="subtotal'+cont+'" >'+subtotal+'</span></td>'+
					'<td><button type="button" onclick="modSubtotales()" class="btn btn-info"><i class="fa fa-refresh" aria-hidden="true"></i></button></td>'+
					'<tr>';
		cont++;
		detalles=detalles+1;
		$("#detalles").append(fila);
		modSubtotales();
	} else {
		alert("Error al ingresar detalle");
	}
}
function modSubtotales(){
	var cant = document.getElementsByName("cantidad[]");
	var prec = document.getElementsByName("precio_venta[]");
	var sub  = document.getElementsByName("subtotal");
	//var desc = document.getElementsByName("descuento");

	for (var i = 0; i <cant.length; i++) {
		var inpC = cant[i];	//Cantidad
		var inpV = prec[i]; //Precio_Venta
		var inpS = sub[i];  //Subtotal
		//var desT = desc[i]; //descuento

		inpS.value=inpC.value * inpV.value; //- ((inpC.value * inpV.value) * (desT.value/100));
		document.getElementsByName("subtotal")[i].innerHTML = inpS.value;
	}
	calcularTotales();
}
function calcularTotales(){
	var sub = document.getElementsByName("subtotal");
	var total = 0.0;
	for (var i = 0; i < sub.length; i++) {
		total += document.getElementsByName("subtotal")[i].value;
	}
	$("#total").html("$ " + total);
	$("#total_venta").val(total);
	evaluar();
}
function evaluar(){
	if (detalles > 0) {
		$("#guardar").show();
	} else {
		$("#guardar").hide();
		cont=0;
	}
}
function eliminarDetalle(indice){
	$("#fila"+indice).remove();
	calcularTotales();
	detalles=detalles-1;
}
function ingresarnew(e){
	//e.preventDefault(); //No se activara la accion predeterminada del evento
	//$("#btnGuardar").prop("disable",true);
	var formData = new FormData($("#frmCliente")[0]);
	$.ajax({
		url: '../../ajax/persona.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			/*Cargar item para select de proveedor */
			$.post("../../ajax/factura.php?op=selectCliente", function(r){
				$("#idcliente").html(r);
				$("#idcliente").selectpicker('refresh');
			});
			$('#ingresarnew').modal('hide');
			mostrarform(true);
		} 
	});
	limpiar();
}
function imprimir_guardar(){
	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: '../../ajax/factura.php?op=guardaryeditar',
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,

		success: function(datos){
			bootbox.alert(datos);  //alertas alert(datos);
			mostrar(idventa, idempresa);
			imprimir()
			
		} 
	});
	limpiar();
}
function imprimir(){
	$("#print").printArea();
}


init();