<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Clientes";
 include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Clientes']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Administrador Clientes</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> + 
      <button class="btn btn-info" onclick="mostrarform(true)">Nuevo cliente  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Tipo ID</th>
              <th>Numero ID</th>
              <th>Dirección</th>
              <th>Telefono</th>
              <th>E-mail</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Tipo ID</th>
              <th>Numero ID</th>
              <th>Dirección</th>
              <th>Telefono</th>
              <th>E-mail</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Registro cliente</h2>
        <form class="form" name="formulario" id="formulario" method="POST" enctype="multipart/form-data"> 
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Nombre(*)</label>
            <input type="hidden" name="idpersona" id="idpersona">
            <input type="hidden" name="tipo_persona" id="tipo_persona" value="Cliente">
            <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre proveedor" required>
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Tipo documento(*)</label>
            <select class="form-control selectpicker" id="tipo_doc" name="tipo_doc" data-live-search="true" required>
              <option value="">-- Selecione --</option>
              <option value="CC">C.C</option>
              <option value="TI">T.I</option>
              <option value="NIT">NIT</option>
            </select>
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Número de documento(*)</label>
            <input type="text" class="form-control" name="num_doc" id="num_doc" maxlength="20" required placeholder="Documento">
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Dirección</label>
            <input type="text" class="form-control" name="direccion" id="direccion" maxlength="70" placeholder="Dirección">
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Teléfono</label>
            <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Teléfono">
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">E-mail</label>
            <input type="text" class="form-control" name="email" id="email" maxlength="50" placeholder="Dirección E-mail">
          </div>
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr>
            <button class="btn btn-success" type="submit" id="btnGuardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/cliente.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>