<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Usuario";
  include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';  
    if ($_SESSION['Usuarios']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Registro de Egresos/Gastos</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> + 
      <button class="btn btn-info" onclick="mostrarform(true)">Generar nueva salida  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Concepto</th>
              <th>Comprobante</th>
              <th>No. Comprobante</th>
              <th>Fecha</th>
              <th>Cantidad</th>
              <th>Total egreso</th>
              <th>Detalle</th>
              <th>Usuario</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Concepto</th>
              <th>Comprobante</th>
              <th>No. Comprobante</th>
              <th>Fecha</th>
              <th>Cantidad</th>
              <th>Total egreso</th>
              <th>Detalle</th>
              <th>Usuario</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Diligencia todos los datos par realizar un nuevo egreso</h2><hr>
        <form class="form " id="formulario" method="post"> 
          <div class="form-group col-lg-8 col-md-8 col-sm-9 col-xs-12">
            <label class="control-label">Detalle concepto(*)</label>
            <input type="hidden" name="idusuario" id="idusuario">
            <input type="text" class="form-control" name="det_concepto" id="det_concepto" placeholder="Concepto de egreso" required>
          </div>
          <div class="form-group col-lg-4 col-md-4 col-sm-3 col-xs-12">
            <label class="control-label">Fecha(*)</label>
            <input type="date" class="form-control data-picker" name="fecha" id="fecha">
          </div>
          <div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <label class="control-label">Tipo salida(*)</label>
            <select class="form-control select-picker" name="tipo_comprobante" id="tipo_comprobante" required>
              <option value="">-- Seleccione --</option>
              <option value="Variable">Egreso Variable</option>
              <option value="Extraordinario">Egreso Extraordinario</option>
              <option value="Otro">Otro...</option>
            </select>
          </div>
          <div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <label class="control-label">Concepto(*)</label>
            <select class="form-control select-picker" name="concepto" id="concepto" required>
              <option value="">-- Seleccione --</option>
              <option value="Nomina">Nomina</option>
              <option value="Gastos Administrativos">Gastos Administrativos</option>
              <option value="Impuesto">Impuestos</option>
              <option value="Arriendo">Arriendo</option>
              <option value="Banco">Bancos</option>
              <option value="Servicio publico">Servicios públicos</option>
              <option value="Papeleria y oficina">Papelería y oficina</option>
              <option value="Insumos">Insumos</option>
              <option value="Gasolina">Gasolina</option>
              <option value="Reparacion y mantenimiento">Reparaciones y manteniento</option>
              <option value="Educacion">Educación(Cursos, asesorias, etc)</option>
              <option value="Entretenimiento">Entretenimiento</option>
              <option value="Otro">Otros...</option>

            </select>
          </div>
          <div class="form-group col-lg-4 col-md-4 col-sm-12 col-xs-12" id="empleados">
            <label class="control-label">Empleado(*)</label>
            <select class="form-control" id="empleado" name="empleado"  disabled style="visibility:hidden">
              
            </select>
          </div>
          <div class="form-group col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <label class="control-label">Total Egreso(*)</label>
            <input type="number" class="form-control" name="total_egreso" id="total_egreso" min="0" placeholder="Costo total de la salida" required>
          </div>          
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr>
            <button class="btn btn-success" type="submit" id="btnGuardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>

        </form>
        <h4><hr>¿Necesitas ayuda?</h4>
        <div>
          <p class="text-"><strong>Egresos variables:</strong> Se conocen también por ser denominados de “explotación”. Como bien indica su nombre, se refiere a aquellos que varían en función de la actividad de la empresa. Así, son aquellos gastos que realiza la compañía para obtener ingresos. Entonces, si el negocio aumenta, significa que los egresos variables también aumentarán. Ejemplos son la mano de obra (ya que cuanta más producción, hará falta más personal), envases empleados para los productos, adquisición de materias primas, etc.<br \><br>
          <strong>Egresos extraordinarios:</strong> Son aquellos que no están ligados a la actividad normal del negocio ni tampoco se presentan en todos los ejercicios. En ocasiones son imprevistos, pues no pueden ser controlados por la propia empresa.</p>
          <small>(*) Campos obligatorios</small>
        </div>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/egreso.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>