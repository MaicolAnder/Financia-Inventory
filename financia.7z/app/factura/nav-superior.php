<?php if (strlen(session_id())<1) {
    session_start();
} else{
?>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="#">FINANCIA</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <?php 
  if ($_SESSION['Facturar']==1) {
    echo '<li class='; if (isset($title) && $title == "Facturar") { echo "active"; } echo ' ><a href="facturar.php"><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Facturar</a></li>';
  } 
  if ($_SESSION['Articulos']==1) {
      echo '<li class='; if (isset($title) && $title == "Artículo") { echo "active"; } echo '><a href="articulo.php"><i class="glyphicon glyphicon-barcode" aria-hidden="true"> </i>  Productos</a></li>';
  }
  if ($_SESSION['Clientes']==1) {
      echo '<li class='; if (isset($title) && $title == "Clientes") { echo "active"; } echo '><a href="cliente.php"><i class="glyphicon glyphicon-user" aria-hidden="true"> </i>  Clientes</a></li>';
  }
  if ($_SESSION['Categorias']==1) {
      echo '<li class='; if (isset($title) && $title == "Categoria") { echo "active"; } echo '><a href="categoria.php"><i class="fa fa-university" aria-hidden="true"> </i>  Categorias</a></li>';
  }
  if ($_SESSION['Proveedores']==1) {
      echo '<li class='; if (isset($title) && $title == "Provedores") { echo "active"; } echo '><a href="Proveedor.php"><i class="fa fa-users" aria-hidden="true"> </i>  Proveedores</a></li>';
  }
  if ($_SESSION['Compras']==1) {
      echo '<li class='; if (isset($title) && $title == "Compras") { echo "active"; } echo '><a href="ingreso.php"><i class="fa fa-truck" aria-hidden="true"> </i>  Compras</a></li>';
  }
  ?>
        
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"> <i class="fa fa-bars" aria-hidden="true"></i> Opciones
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <?php if ($_SESSION['Usuarios']==1) {
      echo '<li class='; if (isset($title) && $title == "Usuario") { echo "active"; } echo '><a href="usuario.php"><i class="fa fa-user-plus" aria-hidden="true"> </i>  Usuarios</a></li>';
  }
  if ($_SESSION['Permisos']==1) {
      echo '<li class='; if (isset($title) && $title == "Permisos") { echo "active"; } echo '><a href="permiso.php"><i class="fa fa-unlock-alt" aria-hidden="true"> </i>  Permisos</a></li>';
  } ?>
  <li role="separator" class="divider"></li>
            <li class="label label-success"><?php echo "  ".$_SESSION['nombre'] ?></li>
            <li role="separator" class="divider"></li>
            <li><a href="" data-toggle="modal" data-target="#config">Configuraciones</a></li>
            <li><a href="">Soporte</a></li>
            <li><a href=""  data-toggle="modal" data-target="#about">Acerca de</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="../../ajax/usuario.php?op=salir" class="btn btn-default"><i class="fa fa-sign-out" aria-hidden="true"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
      <!-- <form class="navbar-form navbar-right">
        <input type="text" class="form-control" placeholder="Search...">
      </form> -->
    </div>
  </div>
</nav>
<!-- Modal Conf-->
<div class="modal fade" id="config" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Configuraciones</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div  class="col-md-12">
          User Name: <?php $_SESSION['usuario_admon'] ?>
          <label class="label label-warning">No disponible en version Demo</label>
        </div>
        
        <div class="col-md-12">
          <label for="tipo_negocio">Tipo de negocio</label>
          <select class="form-control" id="tipo_negocio">
            <option value="TiendaAbarrotes">Tienda de Abarrotes</option>
            <option value="Restaurante">Restaurante</option>
            <option value="Tienda">Tienda ropa</option>
            <option value="Productor_independiente">Productor Independiente</option>
          </select>
        </div>
        <div class="col-md-12">
          <label for="id">NIT / ID</label>
          <input type="text" class="form-control" name="id" id="id">
        </div>
        <div class="col-md-12">
          <label for="virtualShop">Tienda Virtual</label>
          <select class="form-control" id="virtualShop">
            <option value="Activado">Activado</option>
            <option value="Desactivado">Desactivado</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal Acerca de-->
<div class="modal fade" id="about" tabindex="-1" role="dialog" aria-labelledby="about" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Acerca de FINANCIA</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <center>
          <img src="../../files/usuarios/<?php echo $_SESSION['imagen']; ?>" class="img img-resposive img-rounded"><hr>
          <h4>MATE<br>Soluciones software</h4>
          <p>Colombia, 2017.</p>
          <p>Derechos concedido a <?php echo $_SESSION['nombre_empresa'] ?></p>

        </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php } ?>