<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Categoria";
include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';
    if ($_SESSION['Categorias']==1) 
    { ?>
   <div class="right_col" role="main">
    <h1 class="page-header">Categoria de productos</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> +  
      <button class="btn btn-info" onclick="mostrarform(true)">Nueva Categoría <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Registrar categoria</h2>
        <form class="form" id="formulario" method="post"> 
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Nombre</label>
            <input type="hidden" name="idcategoria" id="idcategoria">
            <input type="text" class="form-control" name="nombrec" id="nombrec" maxlength="50" placeholder="Nombre" required>
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Descripción</label>
            <!--<input type="hidden" class="form-control" name="descripcion" id="descripcion"> -->
            <input type="text" class="form-control" name="descripcionc" id="descripcionc" maxlength="256" placeholder="descripcion" required>
          </div>
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr>
            <button class="btn btn-success" type="submit" id="btnGuardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/categoria.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>