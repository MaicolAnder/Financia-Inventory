<?php
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header('location: ../web/ ');
  exit();
} 
else{
 $title = "Usuario";
  include '../elementos/head.php';
?>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php 
        include '../elementos/nav-izquierdo.php';
        include '../elementos/nav-superior.php';  
    if ($_SESSION['Usuarios']==1) 
    { ?>
    <div class="right_col" role="main">
      <h1 class="page-header">Administrador usuarios</h1>
      
      <div class="table-responsive" id="listadoregistro">
      <h2 class="sub-header"> + 
      <button class="btn btn-info" onclick="mostrarform(true)">Nuevo Usuario  <i class="fa fa-plus-square" aria-hidden="true"></i></button></h2>
        <table class="table" id="tbllistado">
          <thead>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Tipo ID</th>
              <th>Número</th>
              <th>Dirección</th>
              <th>Telefóno</th>
              <th>E-mail</th>
              <th>Cargo</th>
              <th>Foto</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
          <tfoot>
            <tr>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Documento</th>
              <th>Número</th>
              <th>Dirección</th>
              <th>Telefóno</th>
              <th>E-mail</th>
              <th>Cargo</th>
              <th>Foto</th>
              <th>Estado</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="panel-body well" id="formularioregistro">
        <h2 class="sub-header">Registro de usuario</h2>
        <form class="form " id="formulario" method="post"> 
          <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <label class="control-label">Nombre(*)</label>
            <input type="hidden" name="idusuario" id="idusuario">
            <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre completo" required>
          </div>
          <div class="form-group col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Tipo de documento(*)</label>
            <select class="form-control select-picker" name="tipo_doc" id="tipo_doc" required>
              <option value="">-- Seleccione --</option>
              <option value="CC">CC</option>
              <option value="TI">TI</option>
              <option value="NIT">NIT</option>
            </select>
          </div>
          <div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">Número(*)</label>
            <input type="text" class="form-control" name="num_doc" id="num_doc" maxlength="20" placeholder="Número documento" required>
          </div>
          <div class="form-group col-lg-4 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">Dirección(*)</label>
            <input type="text" class="form-control" name="direccion" id="direccion" maxlength="70" placeholder="Dirección" required>
          </div>
          <div class="form-group col-lg-4 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">Telefóno(*)</label>
            <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Telefóno" required>
          </div>
          
          <div class="form-group col-lg-4 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">Cargo</label>
            <input type="text" class="form-control" name="cargo" id="cargo" maxlength="20" placeholder="Cargo" >
          </div>
          <div class="form-group col-lg-4 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">E-mail(*)</label>
            <input type="text" class="form-control" name="login" id="login" maxlength="50" placeholder="Login/E-mail" required>
          </div>
          <div class="form-group col-lg-4 col-md-3 col-sm-6 col-xs-12">
            <label class="control-label">Contraseña(*)</label>
            <input type="password" class="form-control" name="clave" id="clave" maxlength="64" placeholder="Contraseña" required>
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Permisos de acceso</label>
            <ul style="list-style: none;" id="permisos">
              
            </ul>
          </div>
          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <label class="control-label">Imagen de perfil</label>
            <input type="file" class="form-control" name="imagen" id="imagen">
            <input type="hidden" name="imgactual" id="imgactual">
            <img src="" width="150px" height="120px" id="imgmuestra">
          </div>
          
          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr>
            <button class="btn btn-success" type="submit" id="btnGuardar"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-times" aria-hidden="true"></i> Cancelar</button>
          </div>
        </form>
      </div>
     </div>
     <?php 
       } else {
          include('../elementos/noacceso.php');
        } ?>
  </div>
</div>
<?php include '../elementos/footer.php';
include '../elementos/footer_scripts.php'; ?>
<script type="text/javascript" src="scripts/usuario.js"></script>
</body>
</html>
<?php 
} 
ob_end_flush(); 
?>